#Written by Eryk Heyssler

#This is a sequential calculator project that can take on variables.
#This code uses concepts of object oriented programming, data structures, and recursion.
#The testbench is included in the bottom of the code.

import math

class Calculator:
    class stack:
        class node:
            def __init__(self, val, nextNode):
                self.val = val
                self.nextNode = nextNode
                
        def __init__(self):
            self.top = None
            self.last = None
            self.size = 0
            
        def __len__(self):
            return self.size
            
        def push(self, val):
            newNode = self.node(val, None)
            if self.size == 0:
                self.top = newNode
                self.last = newNode
                self.size += 1
            elif self.size != 0:
                newNode.nextNode = self.top
                self.top = newNode
                self.size +=1
        
        def pop(self):
            if self.size == 1:
                self.size -=1
                return self.last.val
            elif self.size != 1:
                top_val = self.top.val
                self.top = self.top.nextNode
                self.size -= 1
                return top_val

    def exeOpr(self,num1,opr,num2):
        if opr=="+":
            return num1+num2
        elif opr=="-":
            return num1-num2
        elif opr=="*":
            return num1*num2
        elif opr=="/":
            if num2==0:
                print("zero division error: exeOpr")
                return "zero division error: exeOpr"
            else:
                return num1/num2
        elif opr=="^":
            return num1 ** num2
        else:
            print("fatal internal error in exeOpr")
            return "fatal internal error in exeOpr"
        
    def findNextOpr(self,s):
        if len(s)<=0 or not isinstance(s,str):
            print("type mimatch error: findNextOpr")
            return "type mimatch error: findNextOpr"
        offset = 0
        for i in range(len(s)):
            if self.isNumber(s[:i+1]):
                offset = i
        if offset >= len(s) - 1:
            return -1

        posMinus = s.find('-',offset)
        posPlus = s.find('+',offset)
        posMult = s.find('*',offset)
        posDivide = s.find('/',offset)
        posExponent = s.find('^',offset)

        poslist = [posMinus,posPlus,posMult,posDivide,posExponent]
        poslist_2 = []
        for i in range(len(poslist)):
            if poslist[i] != -1:
                poslist_2.append(poslist[i])
        if poslist_2 == []:
            return -1
        
        return min(poslist_2)

    def isNumber(self,s):
        if not isinstance(s, str):
            print("type mismatch error: isNumber")
            return "type mismatch error: isNumber"
        s = s.strip(" ")
        s = s[0:]
        try:
            s = float(s)
            return True
        except:
            return False

    def isVariable(self,s):
        number_list = ['0','1','2','3','4','5','6',
                       '7','8','9']
        alphabet_list = ['a','b','c','d','e','f','g',
                         'h','i','j','k','l','m','n',
                         'o','p','q','r','s','t','u',
                         'v','w','x','y','z']
        s = s.strip()
        if len(s) == 0:
            return False
        if s[0] not in alphabet_list:
            return False
        for i in range(len(s)):
            if s[i] in number_list or s[i] in alphabet_list:
                pass
            else:
                return False
        return True
        ## It returns True if s is a string
        #   that can be a variable, 
        #   i.e. after striping it consists of only
        #    alphabet letters and 0-9, 
        #    and the first char must be a letter

    def getNextItem(self,expr, pos):
        if len(expr)==0 or not isinstance(expr, str) or pos<0 or pos>=len(expr) or not isinstance(pos, int):
            print("type mismatch error: getNextNumber")
            return None, None, "type mismatch error: getNextNumber"
        #--- function code starts ---#
        try:
            if pos == 0:
                expr_list = expr
                expr_list = list(expr_list)
                modifier = 'f00sh'
                while expr_list[0] == ' ':
                    del expr_list[0]
                if expr_list[0] == '-':
                    modifier = '-'
                elif expr_list[0] == '+':
                    modifier = '+'
                if modifier == '-' or '+':
                    delet = expr.find(modifier)
                    expr = list(expr)
                    if modifier != 'f00sh':
                        expr[delet] = " "
                    expr = ''.join(expr)
            if self.findNextOpr(expr[pos:]) == -1:
                oprPos = None
                newOpr = None
            elif self.findNextOpr(expr[pos:]) != -1:
                oprPos = self.findNextOpr(expr[pos:]) + pos
                newOpr = expr[oprPos]
            if self.isNumber(expr[pos:oprPos]) == True:
                newNumber = list(expr[pos:oprPos])
                if newNumber[0] == ' ':
                    del newNumber[0]
                if newNumber[-1] == ' ':
                    del newNumber[-1]
                newNumber = float(''.join(newNumber))
            elif self.isNumber(expr[pos:oprPos]) == False and self.isVariable(expr[pos:oprPos]) == False:
                if newOpr == '-':
                    newnewOpr = self.findNextOpr(expr[oprPos+1:])
                    if newnewOpr != -1:
                        if self.isNumber(expr[oprPos+1:newnewOpr+oprPos+1]) == True:
                            newNumber = float((expr[oprPos+1:newnewOpr+oprPos+1]).strip(" ")) * -1
                            newOpr = expr[newnewOpr+oprPos+1]
                            oprPos = newnewOpr+oprPos+1
                    elif newnewOpr == -1:
                        if self.isNumber(expr[oprPos+1:]) == True:
                            newNumber = float((expr[oprPos+1:]).strip(" ")) * -1
                            newOpr = None
                            oprPos = None
                else:
                    newNumber = None
            elif self.isVariable(expr[pos:oprPos]) == True:
                newNumber = str(expr[pos:oprPos])
                newNumber = newNumber.strip()
            if pos == 0:
                if modifier == '-' and (isinstance(newNumber,float)):
                    newNumber = newNumber * (-1)
            return newNumber, newOpr, oprPos
        except:
            return "error in getNextNumber"
        #expr is a given arithmetic formula in string
        #pos = start position in expr
        #1st returned value = the next number or a variable(None if N/A)
        #   -- So the change is to recognize a variable
        #2nd returned value = the next operator (None if N/A)
        #3rd retruned value = the next operator position (None if N/A)



    
    
        
    ###functions to change the class instance
    def __init__(self):
        self.lines = []
        self.varDic = {}
        self.functDef='''
        sqrt x: math.sqrt(x) ;
        exp  x: math.exp(x) ;
        sin  x: math.sin(x) ;
        cos  x: math.cos(x) ;
        tan  x: math.tan(x) ;
        ln   x: math.log(x) ;
        lg   x: math.log(x) / math.log(2) ;
        mod x, y: x - y * math.floor(x/y)
        '''
        self.functDic={}
        self.setFunct()



    def setFunct(self):
        # The function refers to self.functDef, 
        #  and set self.functDic to be 
        # {'sqrt': 'x: math.sqrt(x)', 'exp': 'x: math.exp(x)', 'sin': 'x: math.sin(x)',
        #   'cos': 'x: math.cos(x)', 'tan': 'x: math.cos(x)', 'ln': 'x: math.log(x)',
        #   'lg': 'x: math.log(x) / math.log(2)', 'round': 'x, d: round(x, d)'}
        self.functDef = self.functDef.replace('\n','')
        self.functDef = self.functDef.split(';')
        for i in range(len(self.functDef)):
            split = (self.functDef[i]).find('x:')
            if split == -1:
                split = (self.functDef[i]).find('x')
            self.functDic[(self.functDef[i])[:split].strip()] = (self.functDef[i])[split:len(self.functDef[i])].rstrip()
        self.functDic['round'] = 'x, d: round(x,d)'
        
        

    def getLines(self, expr):
        expr = expr.split(';')
        for i in expr:
            e = i.find('=')
            if e == -1:
                e = i.find('return')
                e += 6
                rest = i[e:].strip()
                self.lines.append(['return',rest])
            else:
                var = i[:e].strip()
                rest = i[e+1:].strip()
                self.lines.append([var,rest])                
            
    def _calc(self,expr):
        #expr: nonempty string that is an arithmetic expression
        #the fuction returns the calculated result
        if len(expr)<=0 or not isinstance(expr,str):
            print("argument error: line A in eval_expr")        #Line A
            return "argument error: line A in eval_expr"
        #Initializtion: get the first number
        newNumber, newOpr, oprPos = self.getNextItem(expr, 0)
        if newNumber is None:
            print("input formula error: line B in eval_expr")   #Line B
            return "input formula error: line B in eval_expr"
        elif isinstance(newNumber,str) == True:
            newNumber = self.varDic[newNumber]
            newNumber = float(newNumber)
        elif newOpr is None:
            return newNumber
        elif newOpr=="+" or newOpr=="-":
            mode="add"
            addResult=newNumber     #value so far in the addition mode
            mulResult=None          #value so far in the mulplication mode
            base = None
            lastOpr = newOpr
        elif newOpr=="*" or newOpr=="/":
            mode="mul"
            addResult=0
            mulResult=newNumber
            base = None
            lastOpr = newOpr
        elif newOpr == "^":
            mode = "mul"
            addResult = 0
            mulResult = newNumber
            base = None
            if mulResult < 0:
                lastOpr = '-'
                mulResult *= -1
                newNumber *= -1
            else:
                lastOpr = newOpr
        pos=oprPos+1                #the new current position
        opr=newOpr                  #the new current operator
        while True:
            #--- code while loop ---#
            try:
                newNumber, newOpr, oprPos= self.getNextItem(expr, pos)
                if opr == "/" and newNumber == 0:
                    return 'syntax error: cannot divide by 0'
                if isinstance(newNumber,str) == True:
                    newNumber = self.varDic[newNumber]
                    try:
                        newNumber = float(newNumber)
                    except:
                        return 'syntax error : newNumber'
                if newNumber== None and pos>=len(expr):
                    return 'error'
                elif newOpr== None and mode=='add':                     ###### END, ADD
                    return self.exeOpr(addResult, opr, newNumber)
                elif newOpr== None and mode=='mul':                     ###### END, MUL
                    if base != None:
                        exponent_mult = self.exeOpr(base,'^',newNumber)
                        mulResult = self.exeOpr(mulResult,lastOpr,exponent_mult)
                        if lastOpr == '-' and opr == '^':
                            mulResult *= (-1)
                        return mulResult+addResult
                    mulResult = self.exeOpr(mulResult, opr, newNumber)
                    if lastOpr == '-' and opr == '^':
                        mulResult *= (-1)
                    return mulResult+addResult
                elif (newOpr== "+" or newOpr=='-') and mode=='add' :     ###### ADDITION, ADD
                    addResult= self.exeOpr(addResult,opr,newNumber)
                    lastOpr = opr
                    pos= oprPos+1
                    opr=newOpr
                elif (newOpr=="*" or newOpr=='/') and mode=='add':       ###### MULTIPLICATION, ADD
                    mulResult= newNumber
                    if opr == '-':
                        mulResult = mulResult * (-1)
                    mode='mul'
                    lastOpr = opr
                    pos= oprPos+1
                    opr=newOpr
                elif (newOpr=="*" or newOpr=="/") and mode=="mul":       ###### MULTIPLICATION, MUL
                    if opr == '^' and base != None:
                        exponent_mult = self.exeOpr(base,opr,newNumber)
                        mulResult = self.exeOpr(mulResult,lastOpr,exponent_mult) 
                    else:
                        mulResult = self.exeOpr(mulResult,opr,newNumber)
                    if lastOpr == '-' and opr == '^':
                        mulResult *= (-1)
                    lastOpr = opr
                    pos= oprPos+1
                    opr=newOpr
                    base = None
                elif (newOpr=="-" or newOpr=='+') and mode=="mul":       ###### ADDITION, MUL
                    if opr == '^' and base != None:
                        exponent_mult = self.exeOpr(base,opr,newNumber)
                        mulResult = self.exeOpr(mulResult,lastOpr,exponent_mult) 
                    else:
                        mulResult = self.exeOpr(mulResult,opr,newNumber)
                    if lastOpr == '-' and opr == '^':
                        mulResult *= (-1)
                    addResult += mulResult
                    mode="add"
                    lastOpr = opr
                    pos= oprPos+1
                    opr=newOpr
                elif (newOpr == '^') and mode == "mul":                  ###### EXPONENT, MUL
                    base = newNumber
                    lastOpr = opr
                    pos = oprPos+1
                    opr = newOpr
                elif (newOpr == '^') and mode == "add":                  ###### EXPONENT, ADD
                    mulResult = newNumber
                    lastOpr = opr
                    pos = oprPos+1
                    opr = newOpr
                    mode = "mul"
                    base = None
            except:
                return 'general syntax error'
            #--- end of function ---#

   
    def mask(self, s):
        nestLevel = 0
        masked = list(s)
        for i in range(len(s)):
            if s[i]==")":
                nestLevel -=1
            elif s[i]=="(":
                nestLevel += 1
            if nestLevel>0 and not (s[i]=="(" and nestLevel==1):
                masked[i]=" "
        return "".join(masked)

    def findFunctParen(self,expr):
        # expr = arithmetic expression without a space
        # Find a minimal substring including a function name
        #   and the matched pair of parentheses
        # Return
        #   1st value = the start position of the substring, or None if N/A
        #   2nd value = the end position of the substring, or None if N/A
        #   3rd value = function name, or None if N/A
        #
        # e.g.
        #   s = "2*sin(2*pi)"  -->  returns 2, 10, “sin”
        #   s = "2*32*(2*pi)"  -->  returns 5, 10, None
        #   s = "2*32/8/4/2"   -->  returns None, None, None
        expr = self.mask(expr)
        f = None
        
        for i in self.functDic:
            if i in expr:
                f = i
                break
        if f == None:
            lpos = expr.find('(')
            if lpos == -1:
                lpos = None
                rpos = None
            else:
                rpos = expr.find(')',lpos)
        else:
            lpos = expr.find(f)
        rpos = expr.find(')',lpos)
        if rpos == -1:
            rpos = None
        return lpos,rpos,f

   
    def _calcFunctExpr(self, expr):
        # This allows use of pre-defined functions in one line
        #   returning the calculated value if expr is error-free
        # e.g. expr = 5 / lg ( 2* pi ) 
        #
        # tips:
        #   - remove spaces from expr first
        #   - use findFunctParen
        #   - make recursive calls to calculate the inside parentheses
        #       (or you can use a stack as HW4)
        #   - use exec() or eval() to evaluate a built-in function
        #       with parentheses
        #   - handle two parameters of the round function correctly
        s = self.stack()
        pos = 0
        expr = expr.replace(' ','')
        length = len(expr)
        try:
            while True:
                leftPos,rightPos, f = self.findFunctParen(expr)
 
                if f != None:
                    if (f != 'mod') and (f!= 'round'):
                        insideF = expr[leftPos+len(f)+1:rightPos]
                        recur = str(self._calcFunctExpr(insideF))
                        fBody =  self.functDic[f]
                        evalu = str( eval("(" + "lambda " + fBody  + ")(" + recur + ")"))
                        expr = list(expr)
                        expr[leftPos:rightPos+1] = evalu
                        expr = "".join(expr)
                        break
                    else:
                        if f == 'mod':
                            insideF = expr[leftPos+len(f)+1:rightPos]
                            comma = insideF.find(',')
                            if comma == -1:
                                return 'fatal error'
                            else:
                                modleft = str(insideF[:comma])
                                modright = str(insideF[comma+1:])
                                modleft_result = str(self._calcFunctExpr(modleft))
                                modright_result = str(self._calcFunctExpr(modright))
                                fBody = self.functDic[f]
                                evalu = str( eval("(" + "lambda " + fBody  + ")(" + modleft_result + ',' + modright_result + ")" ) )
                                expr = list(expr)
                                expr[leftPos:rightPos+1] = evalu
                                expr = "".join(expr)
                                break
                        elif f == 'round':
                            insideF = expr[leftPos+len(f)+1:rightPos]
                            comma = insideF.find(',')
                            if comma == -1:
                                return 'fatal error'
                            else:
                                modleft = str(insideF[:comma])
                                modright = str(insideF[comma+1:])
                                modleft_result = str(self._calcFunctExpr(modleft))
                                modright_result = str(int(self._calcFunctExpr(modright)))
                                fBody = self.functDic[f]
                                evalu = str( eval("(" + "lambda " + fBody  + ")(" + modleft_result + ',' + modright_result + ")" ) )
                                expr = list(expr)
                                expr[leftPos:rightPos+1] = evalu
                                expr = "".join(expr)
                                break
                    
                if expr[pos] == '(':
                    s.push(pos)
                    pos +=1
                elif expr[pos] == ')':
                    if s.top == None:
                        return 'parentheses error'
                    x = s.pop()
                    result = self._calc(expr[x+1:pos])
                    expr = list(expr)
                    expr[x] = str(result)
                    new_pos = x + len(str(result))
                    expr[x+1:pos+1] = []
                    expr = "".join(expr)
                    pos = new_pos
                    break
                elif pos == length-1:
                    return self._calc(expr)
                else:
                    pos+=1
        except:
            return 'error'
        return self._calcFunctExpr(expr)


    def calc(self, expr):
        self.getLines(expr)
        varlist = []
        for i in self.lines:
            var = i[0]
            rest = i[1]
            varlist.append(var)
            for x in varlist:
                if x in rest:
                    rest = rest.replace(x,str(self.varDic[x]))
            self.varDic[var] = self._calcFunctExpr(rest)
            if var == 'return':
                self.varDic['__return__'] = self.varDic['return']
                del self.varDic['return']
        if ("__return__" not in self.varDic):
            return '__return__ error'
        return self.varDic["__return__"]
 
            



#To check 
c = Calculator()

s = "n=10000 ; c=5 ; rt = n * lg(n) ; return rt "
print("input: "+ s + "\n" + "output: " + str(c.calc(s)))
print(c.varDic)

#s = "var1 = 10000 ; var2 = 5 ; runningTime = var2 * var1 *lg(var2) ; return runningTime"
#s = "var1 = 800^2/(32*4-100) ; var2 = sqrt(var1) ; var3 = lg(var2) ; return sin(var3)"
#s = "var0 = 11*8 ; var2 = mod(var0,7) ; var1 = ln( 2*cos(.3) )* 5 ; return var2*var1"
#print("input: "+ s + "\n" + "output: " + str(c.calc(s)))
#print(c.varDic)




