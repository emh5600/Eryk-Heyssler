/*
 * mm.c
 *
 * Name: Eryk Heyssler
 *
 *

****************************************************************************************************************************
02.21.2020

--------------------------Basic Structure--------------------------
This implementation is in the form of a segregated free list.

Each block in the heap is either allocated or free.

Allocated blocks contain a header and a footer, both containing the same information, namely
the size of the block, as well as a 1 bit tag that indicates whether the block is allocated (1)
or free (0). The header and footer allows for easy traversal of the heap.

Free blocks, in addition to a header and a footer, contain a predecessor pointer and a successor pointer.
These pointers point to the previous and next free blocks respectively in the free list.

The payload must be aligned to 16 bytes, therefore, there may exist optional padding in each allocated block.
Additionally, the minimum block size is 32 bytes, as free blocks require 16 bytes for the header and footer,
as well as another 16 bytes for both of the pointers.

The heap structure is initialized through mm_init; it instantiates the heap by adding a prologue and epilogue,
a free block of size 32 bytes, as well as a heap pointer that points to the beginning of the heap.

Allocated blocks:

+---------------------------------------------------------------+
|					     HEADER (8 bytes)						|
|---------------------------------------------------------------|				
|							  PAYLOAD							|
|																|
|																|
|---------------------------------------------------------------|
|						 OPTIONAL PADDING					    |
|---------------------------------------------------------------|
|						 FOOTER (8 bytes)					    |
+---------------------------------------------------------------+

Free blocks:

+---------------------------------------------------------------+
|					      HEADER (8 bytes)						|
|---------------------------------------------------------------|				
|				      PREDECESSOR PTR (8 bytes)					|
|---------------------------------------------------------------|
|				      SUCCESSOR PTR (8 bytes)					|
|---------------------------------------------------------------|
|						    PAYLOAD								|
|																|
|																|
|---------------------------------------------------------------|
|						 FOOTER (8 bytes)					    |
+---------------------------------------------------------------+

The heap structure also contains a prologue and an epilogue. These are simply allocated blocks that 
mark the beginning and end of the heap and allow for easy handling of edge cases. 

The segregated free list consists of 12 doubly-linked free lists, each bounded
in size by a number of bytes to the power of 2. For each free list, there exists
a pointer to the head of that free list. The 12th free list is of an unrestricted size.

--------------------------Malloc--------------------------
When malloc is called, the smallest possible free list is traversed based on the size requested by malloc. 
If there does not exist a free block in this list, the next, larger free list is traversed to find a fit.
If no free list contains a block that can accomodate the request, the extend_heap function is called to
add more memory to the heap and place a new free block in a selected free list based on the size of the
malloc request. 

If there does exist a free block that can fit the malloc request, the place function is called, and allocates
the free block. If the free block is relatively large, meaning that the remainding space after allocation is equal to
or larger than the minimum free block size (32 bytes), the block is split, and the remainder is appended to a free list.

The free lists follow a LIFO structure; every new free block is added to the head of the free list.

--------------------------Free--------------------------
When free is called, an allocated block is converted to a free block and appended to the appropriate free list.
The design calls for immediate coalescing; adjacent free blocks are automatically merged and appended to a free list,
possibly of a different size class.

--------------------------Realloc--------------------------
Realloc is a simple wrapper function for malloc that reallocates an allocated block to a new block of a different size.
It works by first allocating a free block using the malloc function, copying the data from the previously allocated block
to the newly allocated block, and then calling the free function on the previously allocated block. 

*****************************************************************************************************************************/


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>

#include "mm.h"
#include "memlib.h"

//#define DEBUG

#ifdef DEBUG
/* When debugging is enabled, the underlying functions get called */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_assert(...) assert(__VA_ARGS__)
#else
/* When debugging is disabled, no code gets generated */
#define dbg_printf(...)
#define dbg_assert(...)
#endif /* DEBUG */

/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#define memset mem_memset
#define memcpy mem_memcpy
#endif /* DRIVER */

/* What is the correct alignment? */
#define ALIGNMENT 16

/******************************************************************************
|					constants & header/footer logic 						  |
******************************************************************************/

/* The original macros that these functions are based on come from 
* Chapter 9, figure 9.43 of the 'Computer Systems: A Programmers Perspective' textbook.
*/

#define WSIZE				8			//word and header/footer size in bytes
#define DSIZE				16			//double word size in bytes

#define FSIZE				sizeof(void*)			//size of a pointer
#define CHUNKSIZE 			align(DSIZE + FSIZE*2)	//minimum free block size

//Each allocated block contains a header, optional padding, and a footer.
//Each free block contains a header, predecessor, successor, optional padding, and a footer.

//Return the maximum given two values
static size_t MAX(size_t x,size_t y){
	return ((x) > (y) ? (x) : (y));
}

//Return the minimum given two values
static size_t MIN(size_t x,size_t y){
	return ((x) < (y) ? (x) : (y));
}

//Pack a size and allocated bit into a word
static size_t PACK(size_t size, size_t alloc){
	return ((size) | (alloc));
}

//Read and write a word at address p
static size_t GET(void *p){
	return (*(size_t *)(p));
}
static void PUT(void *p, size_t val){
	(*(size_t *)(p) = (val));
}

//Read the size and allocated fields from address p
static size_t GET_SIZE(void* p){
	return (GET(p) & ~0x7);
}
static char GET_ALLOC(void* p){
	return (GET(p) & 0x1);
}

//Given block pointer bp, compute address of its header and footer
static void* HDRP(void* bp){
	return ((char *)(bp) - WSIZE);
}
static void* FTRP(void* bp){
	return ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE);
}

// Given block pointer bp, compute address of next and previous blocks
static void* NEXT_BLKP(void* bp){
	return ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE)));
}
static void* PREV_BLKP(void* bp){
	return ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE)));
}

// rounds up to the nearest multiple of ALIGNMENT
static size_t align(size_t x)
{
    return ALIGNMENT * ((x+ALIGNMENT-1)/ALIGNMENT);
}

/******************************************************************************
|		        New declarations and explicit free list helpers				  |
******************************************************************************/
static void* extend_heap(size_t words); //invokes mem_sbrk to extend the heap (textbook, Ch. 9)
static void* coalesce_free(void *bp); //Merges adjacent free blocks (textbook, Ch. 9)
static void place(void *bp, size_t asize); //Allocates a free block, splitting if necessary (textbook, Ch. 9)
static void* find_fit(size_t asize); //Traverses segregated free list and returns a pointer to the next fit

//Explicit Free List 
static void** PRED(void* bp){	//gets the predecessor of a free block
	return (void**)(bp);
}

static void** SUCC(void* bp){	//gets the successor of a free block
	return (void**)((bp) + FSIZE);
}

static void SET_PRED(void* bp, void* pred){	//sets the predecessor of a free block
		*PRED(bp) = pred;
}

static void SET_SUCC(void* bp, void* succ){	//sets the successor of a free block
		*SUCC(bp) = succ;
}

static void link_free_blocks(void* bp);	//Makes a free block 'obsolete' -- joins its successor with its predecessor 


//Global pointers
static void* heap_listp; //Pointer to the beginning of the heap

//Segregated free list declarations
static void *free_listp8;
static void *free_listp16;
static void *free_listp32;
static void *free_listp48;
static void *free_listp64;
static void *free_listp128;
static void *free_listp256;
static void *free_listp512;
static void *free_listp1024;
static void *free_listp2048;
static void *free_listp4096;
static void *free_listpinf;


//Functions unique to segregated free list 
static void* choose_free_list(size_t size); //Returns a pointer to the head of a free list given a size
static void add_to_free_list(void* bp, size_t size); //appends a free block to the head of a free list
static void insert_to_free_list(void* bp, size_t size);	//append an existing free block to the head of a free list
static bool update_head_free_list(void* oldptr,void* free_listp); //changes the pointer that corresponds to the head of a free list

//Checking Code
static void printheap();
bool check_malloc(void* bp);
bool check_free_list_heap();
bool check_seg_free_list();


/******************************************************************************
|								 Initialization  							  |
******************************************************************************/

/*Set all pointers to NULL for each call of mm_init, that way the pointers don't point to any garbage values after the first set of instructions */ 
static void init_pointers(){
	heap_listp = NULL;

	free_listp8 = NULL;
	free_listp16 = NULL;
	free_listp32 = NULL;
	free_listp48 = NULL;
	free_listp64 = NULL;
	free_listp128 = NULL;
	free_listp256 = NULL;
	free_listp512 = NULL;
	free_listp1024 = NULL;
	free_listp2048 = NULL;
	free_listp4096 = NULL;
	free_listpinf = NULL;
}

/*
 * Initialize: returns false on error, true on success.
 * Chapter 9, figure 9.44, 'Computer Systems: A Programmers Perspective' textbook. 
 * Sets up a prologue, epilogue, and a free block of size 32 bytes.
 */
bool mm_init(void)
{
	init_pointers();

    /* Create the initial empty heap */
    if ((heap_listp = mem_sbrk(4*WSIZE)) == (void *)-1)
		return false;

    PUT(heap_listp, 0);                          /* Alignment padding */
    PUT(heap_listp + (1*WSIZE), PACK(DSIZE, 1)); /* Prologue header */ 
    PUT(heap_listp + (2*WSIZE), PACK(DSIZE, 1)); /* Prologue footer */ 
    PUT(heap_listp + (3*WSIZE), PACK(0, 1));     /* Epilogue header */
    heap_listp += (2*WSIZE);  

    /* Extend the empty heap with a free block of CHUNKSIZE bytes */
    if (extend_heap(CHUNKSIZE/WSIZE) == NULL)
		return false;

    return true;
}

/******************************************************************************
|							 Manipulating Space  							  |
******************************************************************************/

/* Chapter 9, figure 9.45, 'Computer Systems: A Programmers Perspective' textbook. 
 * Adds more memory to the heap by calling mem_sbrk and appending a free block to the appropriate list.
 */
static void *extend_heap(size_t words)
{
	char *bp;
	size_t size;

	/* Allocate an even number of words to maintain alignment */
	size = (words % 2) ? (words+1) * WSIZE : words * WSIZE;
	if ((long)(bp = mem_sbrk(size)) == -1)
		return NULL;

	/* Initialize free block */
	add_to_free_list(bp,size);

	/* New epilogue header */
	PUT(HDRP(NEXT_BLKP(bp)),PACK(0, 1));

	return bp;
}

/* Iterates through the appropriate free list to find an appropriate fit */
static void *find_fit(size_t asize){
	int i = -1;
	void* seg_free_listp[12] = {
		&free_listp8,
		&free_listp16,
		&free_listp32,
		&free_listp48,
		&free_listp64,
		&free_listp128,
		&free_listp256,
		&free_listp512,
		&free_listp1024,
		&free_listp2048,
		&free_listp4096,
		&free_listpinf
	};

	void *bp = choose_free_list(asize);
	if (bp == &free_listp8)
		i = 0;
	else if (bp == &free_listp16)
		i = 1;
	else if (bp == &free_listp32)
		i = 2;
	else if (bp == &free_listp48)
		i = 3;
	else if (bp == &free_listp64)
		i = 4;
	else if (bp == &free_listp128)
		i = 5;
	else if (bp == &free_listp256)
		i = 6;
	else if (bp == &free_listp512)
		i = 7;
	else if (bp == &free_listp1024)
		i = 8;
	else if (bp == &free_listp2048)
		i = 9;
	else if (bp == &free_listp4096)
		i = 10;
	else if (bp == &free_listpinf)
		i = 11;

	/* Iterate through a free list; if no block is found, iterate through the next free list of a larger size */
	for (int j = i; j < 12; j++){
		bp = *(void**)seg_free_listp[j];
		while (bp){
			if (!GET_ALLOC(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp)))){
				return bp;
			}
			bp = *SUCC(bp);
		}
		j++;
	}

	return NULL; /* No fit */
}

/******************************************************************************
|									 Malloc 	  							  |
******************************************************************************/

/*
 * malloc
 * Chapter 9, figure 9.47, 'Computer Systems: A Programmers Perspective' textbook. 
 * First, we call the find_fit function to see if there is an available free block.
 * If there isn't we call the extend_heap function to add a new free block to the heap.
 */
void* malloc(size_t size)
{
	size_t asize;		/* Adjusted block size */
	size_t extendsize; 	/* Amount to extend heap if no fit */
	char *bp;

	/* Ignore spurious requests */
	if (size == 0)
		return NULL;

	/* Adjust block size to include overhead and alignment reqs. */
	if (size <= DSIZE)
		asize = 2*DSIZE;
	else
		asize = align(size + DSIZE);	//align function for padding
										//DSIZE for adding header and footer

	/* search free list for a fit */
	if ((bp = find_fit(asize)) != NULL){
		place(bp,asize);
		#ifdef DEBUG
			check_malloc(bp);
		#endif
		return bp;
	}

	/* If no fit found, get more memory and then place the block */
	extendsize = MAX(asize,CHUNKSIZE);
	if ((bp = extend_heap(extendsize/WSIZE)) == NULL)
		return NULL;
	place(bp, asize);
	#ifdef DEBUG
		check_malloc(bp);
		mm_checkheap(__LINE__);
	#endif
	return bp;
}

/* Chapter 9, Practice problem 9.9, 'Computer Systems: A Programmers Perspective' textbook. 
 *  Allocates a free block by changing the tags in the header and footer
 *  If a free block is big enough, meaning that the remainder is greater than or equal to the minimum 
 *  block size, then we can append the remainder to a free list.
 */
static void place(void *bp, size_t asize){
	size_t csize = GET_SIZE(HDRP(bp));
	void* free_listp = choose_free_list(csize); //for checking if oldptr references a head
	if ((csize - asize) >= (2*DSIZE)) {
		/*If big enough, split the free block*/

		/*Grab references of old pointer*/
		void* oldptr = bp;
		link_free_blocks(bp); //Remove bp from the list since it's allocated now

		/*Split the block*/
		PUT(HDRP(bp), PACK(asize, 1));
		PUT(FTRP(bp), PACK(asize, 1));
		bp = NEXT_BLKP(bp);

		/*If we split the head, update the global pointer*/
		update_head_free_list(oldptr,free_listp);

		/* Add the split part to the head of a new free list */
		insert_to_free_list(bp,csize-asize);

		PUT(HDRP(bp), PACK(csize-asize, 0));
		PUT(FTRP(bp), PACK(csize-asize, 0));

	}
	else {
		/*Block is not split*/
		link_free_blocks(bp);

		update_head_free_list(bp,free_listp); //in case the block we are allocating is the head of a free list

		PUT(HDRP(bp), PACK(csize, 1));
		PUT(FTRP(bp), PACK(csize, 1));
	}
}

/******************************************************************************
|					      explicit free list functions 						  |
******************************************************************************/
/* Returns the correct free list for the given size */
static void* choose_free_list(size_t size){
	if (size <= 8){
		return &free_listp8;
	}
	else if (size <= 16){
		return &free_listp16;
	}
	else if (size <= 32){
		return &free_listp32;
	}
	else if (size <= 48){
		return &free_listp48;
	}
	else if (size <= 64){
		return &free_listp64;
	}
	else if (size <= 128){
		return &free_listp128;
	}
	else if (size <= 256){
		return &free_listp256;
	}
	else if (size <= 512){
		return &free_listp512;
	}
	else if (size <= 1024){
		return &free_listp1024;
	}
	else if (size <= 2048){
		return &free_listp2048;
	}
	else if (size <= 4096){
		return &free_listp4096;
	}
	else{
		return &free_listpinf;
	}
}

/******************************************************************************
|							manipulating free list 							  |
******************************************************************************/
/* Initialize new free block 
 * LIFO policy, add block to head of free list
 * Used when we require more memory for the heap or are freeing a block and coalescing is not necessary
 */
static void add_to_free_list(void *bp,size_t size){
	/* Find appropriate free list based on the size */
	static void* free_listp;
	free_listp = choose_free_list(size);

	if (*(void**)free_listp){
		//Set successor of new node to the head
		SET_SUCC(bp,*(void**)free_listp);
		//Set predecessor of previous head to the new block
		SET_PRED(*(void**)free_listp,bp);
	}
	else
		SET_SUCC(bp,NULL);

	SET_PRED(bp,NULL);

	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
	
	*(void**)free_listp = bp; //update the head of the free list.
}

/* Insert an already existing free block at the head of a free list*/
static void insert_to_free_list(void *bp,size_t size){
	void* new_free_listp = choose_free_list(size);

	SET_SUCC(bp,*(void**)new_free_listp);
	if (*(void**)new_free_listp){
		SET_PRED(*(void**)new_free_listp,bp);		
	}
	SET_PRED(bp,NULL);

	*(void**)new_free_listp = bp;
}

/* Updates the head of a free list based on a pointer 
 *  Returns true if the orignal head and the pointer (argument) point to the same place
 *  Used primarily when coalescing or allocating a free block when it is the head of a free list
 */
static bool update_head_free_list(void* bp, void* free_listp){
	if (bp == *(void**)free_listp){
		*(void**)free_listp = *SUCC(*(void**)free_listp);
		if (*(void**)free_listp){
			SET_PRED(*(void**)free_listp,NULL);		
		}
		return true;
	}
	return false;
}

/* 'Links' a free blocks successor and predecessor
 *  Essentially removes the current free block from the linked list
 */
static void link_free_blocks(void *bp){
	void* pred = *PRED(bp);
	void* succ = *SUCC(bp);

	if (succ){
		SET_PRED(succ,pred);
	}
	if (pred){
		SET_SUCC(pred,succ);
	}

}

/******************************************************************************
|						    	Free & helpers 			     				  |
******************************************************************************/
/*
 * Frees up current block and coalesces if necessary
 * Chapter 9, figure 9.46, 'Computer Systems: A Programmers Perspective' textbook.
 */
void free(void* ptr)
{
	size_t size = GET_SIZE(HDRP(ptr));

	PUT(HDRP(ptr),PACK(size,0));
	PUT(FTRP(ptr),PACK(size,0));
	
	coalesce_free(ptr);
	#ifdef DEBUG
		mm_checkheap(__LINE__);
	#endif
}

/* Chapter 9, figure 9.46, 'Computer Systems: A Programmers Perspective' textbook. 
 * Coalesces after freeing a block. There are four cases to consider.
 * Case 1: No adjacent free blocks
 * Case 2: The previous block is free
 * Case 3: The next block is free_listp
 * Case 4: Both the previous and the next blocks are free_listp
 * The logic is also more complex due to the fact that certain free blocks may be the heads of a free list.
 */
static void* coalesce_free(void *bp)
{
	size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	size_t size = GET_SIZE(HDRP(bp));

	/* Case 1 A-F-A */
	if (prev_alloc && next_alloc) 						
		add_to_free_list(bp,size); //simply add the free block to a list 
	/* Case 2 A-F-F */	
	else if (prev_alloc && !next_alloc) {
		void* free_listp = choose_free_list(GET_SIZE(HDRP(NEXT_BLKP(bp))));
		link_free_blocks(NEXT_BLKP(bp)); //make block obsolete

		//update the head of the list that corresponds to next block 
		update_head_free_list(NEXT_BLKP(bp),free_listp);

		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		PUT(HDRP(bp), PACK(size, 0));
		PUT(FTRP(bp), PACK(size,0));

		//Add to head of new list
		insert_to_free_list(bp,size);
	}
	/* Case 3 F-F-A */
	else if (!prev_alloc && next_alloc) {
		size_t left_size = GET_SIZE(HDRP(PREV_BLKP(bp)));
		size += left_size;

		PUT(FTRP(bp), PACK(size, 0));

		if (choose_free_list(left_size) == choose_free_list(size))
			/*If combined size belongs to the same size class*/ 
			bp = PREV_BLKP(bp);
		else{
			/*Otherwise if they do not belong to the same size class, we need to update the pointers. */
			bp = PREV_BLKP(bp);
			link_free_blocks(bp);

			//Check if bp is the head of a free list
			void* free_listp = choose_free_list(left_size);
			update_head_free_list(bp,free_listp);
			//Add bp to its corresponding list
			insert_to_free_list(bp,size);
		}

		PUT(HDRP((bp)), PACK(size, 0));
	}
	/* Case 4 F-F-F */
	else if (!prev_alloc && !next_alloc){
		void* left = PREV_BLKP(bp);
		void* right = NEXT_BLKP(bp);		

		void* left_free_listp = choose_free_list(GET_SIZE(HDRP(left)));		//Head of the free list that left belongs to 
		void* right_free_listp = choose_free_list(GET_SIZE(HDRP(right)));	//Head of the free list that right belongs to
		
		/* edge case 1: block on the right is a head*/
		if (!update_head_free_list(right,right_free_listp)){
			link_free_blocks(right);
		}
		/* edge case 2: block on the left is a head */
		if(!update_head_free_list(left,left_free_listp)){
			link_free_blocks(left);
		}

		size += GET_SIZE(HDRP(PREV_BLKP(bp))) +
		GET_SIZE(FTRP(NEXT_BLKP(bp)));
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));

		bp = PREV_BLKP(bp);

		/* Insert new coalesced block into a free list as the head */
		insert_to_free_list(bp,size);

	}
	return bp;
}

/*
 * realloc - simple wrapper function of malloc and free
 * Change the size of the memory block pointed to by ptr & returns the address of the new block.
 */
void* realloc(void* oldptr, size_t size)
{
	void *bp = malloc(size);
	size_t newsize = MIN(size,GET_SIZE(HDRP(oldptr)));
	memcpy(bp,oldptr,newsize);

	free(oldptr);
	oldptr = bp;

	return oldptr;
}

/*
 * calloc
 * This function is not tested by mdriver, and has been implemented for you.
 */
void* calloc(size_t nmemb, size_t size)
{
    void* ptr;
    size *= nmemb;
    ptr = malloc(size);
    if (ptr) {
        memset(ptr, 0, size);
    }
    return ptr;
}

/******************************************************************************
|						    		Debugging			     				  |
******************************************************************************/

/*
 * Returns whether the pointer is in the heap.
 * May be useful for debugging.
 */
static bool in_heap(const void* p)
{
    return p <= mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Returns whether the pointer is aligned.
 * May be useful for debugging.
 */
static bool aligned(const void* p)
{
    size_t ip = (size_t) p;
    return align(ip) == ip;
}


/* Print the entire heap, including the prologue and epilogue
 * If a block is free, also print its successor and predecessor
 */
static void printheap(){
	void *bp = heap_listp;
	while(bp < mem_heap_hi()){
		if (GET_ALLOC(HDRP(bp))){
			printf("A: %p, size %zu\n",bp,GET_SIZE(HDRP(bp)));
		}
		else{
			printf("F: %p, size %zu, pred %p, succ %p\n",bp,GET_SIZE(HDRP(bp)),*PRED(bp),*SUCC(bp));
		}

		bp = NEXT_BLKP(bp); 

	}
	printf("A: %p, size %zu\n",bp,GET_SIZE(HDRP(bp)));
}

/* Print all the free lists in the segregated free list.
 * For each head, print its successors.
 */
static void print_seg_free_list(){
	void* free_listp;
	void* seg_free_listp[8] = {
		&free_listp8,
		&free_listp16,
		&free_listp32,
		&free_listp128,
		&free_listp256,
		&free_listp1024,
		&free_listp4096,
		&free_listpinf
	};
	for (int i = 0; i < 8; i++){
		free_listp = *(void**)seg_free_listp[i];
		printf("LIST %d  HEAD: %p\n",i,free_listp);
		if (free_listp){
			printf("	SUCCESSORS:\n");
			while (free_listp){
				free_listp = *SUCC(free_listp);
				printf("		%p\n",free_listp);
			}
		}

	}
	
}

/* Print all information at once */
static void printall(){
	printheap();
	printf("\n");
	print_seg_free_list();
}


/* Count the number of free blocks in the heap */
static int check_num_free_in_heap(){
	void *bp = heap_listp;
	int count = 0;
	while(bp < mem_heap_hi()){
		if (!GET_ALLOC(HDRP(bp))){
			count++;
		}
		bp = NEXT_BLKP(bp); 
	}
	return count;
}


/* Basic malloc invariant checks */
bool check_malloc(void* bp){
	//1 if error, 0 if no error.
	int flag = 0;

		
	//check if pointer is in the heap.
	if (!in_heap(bp)){
		printf("[!] %p IS NOT IN THE HEAP [!]\n",bp);
		flag = 1;
	}

	//check if pointer is aligned 
	if (!aligned(bp)){
		printf("[!] %p IS NOT ALIGNED [!]\n",bp);
		flag = 1;
	}

	//print information if there is an error
	if (flag){
		//printheap();
		return false;
	}
	return true;

}

/* Check invariants of the free list as it exists in the heap 
 * The invariants that are checked are the links between the free blocks.
 */
bool check_free_list_heap(){
	void *bp = heap_listp;
	void *fbp = NULL;
	int flag = 0;
	while(bp < mem_heap_hi()){
		if(!GET_ALLOC(HDRP(bp))){
			fbp = bp;
			fbp = *SUCC(bp);
			if (fbp){
				//Make sure that the successor of a free block, if it exists, exists as part of the heap.
				//If this fails, we know there is a problem with coalescing
				if (!in_heap(fbp)){
					printf("[!] %p, A FREE BLOCK, IS NOT IN THE HEAP [!]\n",fbp);
					flag = 1;
					break;
				}
				//Check if a free block, and its successor, are linked.
				//Linking problems occur either during place, or during coalescing
				if (*PRED(fbp) != bp){
					printf("[!] %p, FREE BLOCK IS NOT LINKED [!]\n",fbp);
					printf("F: %p, size %zu, pred %p, succ %p\n",bp,GET_SIZE(HDRP(bp)),*PRED(bp),*SUCC(bp));
					printf("F: %p, size %zu, pred %p, succ %p\n",fbp,GET_SIZE(HDRP(fbp)),*PRED(fbp),*SUCC(fbp));
					flag = 1;
					break;				
				}
			}
		}

		bp = NEXT_BLKP(bp); 
	}
	if (flag)
		return false;
	return true;
}

/* Check invariants of the segregated free list, namely the head pointers.
 * If there is a problem here, we know that there is a case where a head of a list is being
 * modified, either through coalescing or splitting.
 */
bool check_seg_free_list(){
	void* free_listp;
	void* free_listp_comp;
	int flag = 0;

	void* seg_free_listp[8] = {
		&free_listp8,
		&free_listp16,
		&free_listp32,
		&free_listp128,
		&free_listp256,
		&free_listp1024,
		&free_listp4096,
		&free_listpinf
	};
	for (int i = 0; i < 8; i++){
		free_listp = *(void**)seg_free_listp[i];
		//Every head of a free list must have a null predecessor.
		if (free_listp){
			if (*PRED(free_listp)){
				printf("[!] %p PREDECESSOR OF HEAD IS NOT NULL [!]\n",free_listp);
				flag = 1;
				break;
			}	
		}
		//Every head of a segregated free list is unique -- it cannot appear in more than one place
		//The logic for coalescing and splitting that DO NOT involve heads of lists is easy, because
		//there is nothing extraneous that has to happen. This is why this check is mainly focused on the heads.
		for (int j = i+1; j < 8; j++){
			free_listp_comp = *(void**)seg_free_listp[j];
			if (free_listp_comp && free_listp){
				if (free_listp_comp == free_listp){
					printf("[!] %p APPEARS AS THE HEAD OF 2 LISTS [!]\n",free_listp_comp);
					flag = 1;
					break;
				}
				else{
					//Check whether the successors have been properly set, namely as valid values.
					free_listp_comp = *SUCC(free_listp_comp);
					if (free_listp_comp){
						if (!(in_heap(free_listp_comp))){
							printf("[!] %p NOT IN HEAP [!]\n",free_listp_comp);
							flag = 1;
							break;
						}
						if (free_listp_comp == free_listp){
							printf("[!] %p APPEARS AS A SUCCESSOR IN ANOTHER LIST [!]\n",free_listp_comp);
							flag = 1;
							break;
						}
					}
				}
			}

		}
		if (flag)
			break;
	}
	if (flag)
		return false;
	return true;
}

/*
 * mm_checkheap
 * Wrapper function for the free list invariant checkers.
 * Calling mm_checkheap allows us to further deduce where the free list bug is happening,
 * whether it is in the PLACE function after calling malloc, or COALESCE_FREE function after calling free.
 */
bool mm_checkheap(int lineno){
#ifdef DEBUG
	int flag = 0;
	//check if free list in the heap is correct
	if (!check_free_list_heap())
		flag = 1;

	//check for invariants in segregated free list
	if (!check_seg_free_list())
		flag = 1;

	//print information if there is an error
	if (flag){
		//printheap();
		if (lineno == 435 ){
			printf("[!] ERROR IN FREE LIST -- PLACE [!] \n");
		}
		else{
			printf("[!] ERROR IN FREE LIST -- COALESCE_FREE [!] \n");
		}
		return false;
	}
	return true;
#endif /* DEBUG */
    return true;
}









