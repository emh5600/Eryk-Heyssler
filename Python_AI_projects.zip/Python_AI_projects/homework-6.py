############################################################
# CMPSC 442: Homework 6
############################################################

student_name = "Eryk Heyssler"

############################################################
# Imports
############################################################

# Include your imports here, if any are used.

############################################################
# Section 1: Hidden Markov Models
############################################################

def load_corpus(path):
    corpus = []
    with open(path,'r') as trainingFile:
        sentences = trainingFile.read().splitlines()
        for sentence in sentences:
            corpusLine = []
            for tagPair in sentence.split(' '):
                corpusLine.append(tuple(tagPair.split('=')))
            corpus.append(corpusLine)

    return corpus

class Tagger(object):

    def __init__(self, sentences):
        self.a = 1e-9 #smoothing constant

        # *1*
        self.init_probs = {} #log() probability with laplace smoothing that a sentence begins with tag t

        # *2*
        self.trans_probs = {} #log() probability with laplace smoothing that a tag ti occurs before tj
        trans_probs_helper = {} #total counts for each prev_tag to help with calculating probability

        # *3*
        self.em_probs = {} #log() probability with laplace smoothing that a token wj is generated given tag ti
        em_probs_helper = {} #total counts for each tag to help with calculating probability

        #Gather necessary counts for each probability
        for sentence in sentences:
            prev_tag = "" # *2* - Keep track of the previous tag in each sentence

            for (word,tag) in sentence:
                # *1* - Dictionary temporarily of the form {tag : count of times a sentence starts it}
                if (prev_tag == ""): #Make sure we only update when we are at the beginning of a sentence
                    if tag in self.init_probs:
                        self.init_probs[tag] += 1
                    else:
                        self.init_probs[tag] = 1

                # *2* - Dictionary temporarily of the form - {prev_tag : {tag : count of times tag occurs after prev_tag}}
                # Helper = {prev_tag : summation of counts in above dictionary}
                if (prev_tag != ""):
                    if prev_tag in self.trans_probs:
                        if tag in self.trans_probs[prev_tag]:
                            self.trans_probs[prev_tag][tag] += 1
                        else:
                            self.trans_probs[prev_tag][tag] = 1
                        # update helper
                        trans_probs_helper[prev_tag] += 1
                    else:
                        self.trans_probs[prev_tag] = {tag:1}
                        # set helper
                        trans_probs_helper[prev_tag] = 1

                prev_tag = tag

                # *3* - Dictionary temporarily of the form {tag : {word : count of times the pair occurs}}
                # Helper = {tag : summation of counts in above dictionary}
                if tag in self.em_probs:
                    if word in self.em_probs[tag]:
                        self.em_probs[tag][word] += 1
                    else:
                        self.em_probs[tag][word] = 1
                    # update helper
                    em_probs_helper[tag] += 1
                else:
                    self.em_probs[tag] = {word:1}
                    # set helper
                    em_probs_helper[tag] = 1


        # Calculating the different probabilities given the counts computed in the above iteration
        # *1*
        num_sentences = len(sentences)
        num_tags = len(self.init_probs)

        for tag in self.init_probs:
            # smoothed probability : (count(w) + a) / (summation(count(w')) + a (|V| + 1))
            self.init_probs[tag] = (self.init_probs[tag] + self.a)/(num_sentences + self.a * (num_tags + 1))

        # *2*
        for prev_tag in self.trans_probs:
            num_tags = len(self.trans_probs[prev_tag])
            for tag in self.trans_probs[prev_tag]:  #probability for every pair of tags (ti, tj)
                self.trans_probs[prev_tag][tag] = (
                    (self.trans_probs[prev_tag][tag] + self.a) /
                    (trans_probs_helper[prev_tag] + self.a * ( num_tags + 1))
                )

        # *3*
        for tag in self.em_probs:
            summ_word_count = em_probs_helper[tag]
            num_words = len(self.em_probs[tag])
            for word in self.em_probs[tag]:
               self.em_probs[tag][word] = (
                   (self.em_probs[tag][word] + self.a) /
                   (summ_word_count + self.a * (num_words + 1))
               )
            #For an unknown word:
            self.em_probs[tag]["<UNK>"] = (self.a) / (summ_word_count + self.a * (num_words + 1))

    def most_probable_tags(self, tokens):
        ret = []
        for token in tokens:
            prob = (0,"NONE")
            for tag in self.em_probs:
                if token in self.em_probs[tag]:
                    inner_prob = self.em_probs[tag][token]
                else:
                    inner_prob = self.em_probs[tag]["<UNK>"]

                if (prob[0] < inner_prob):
                    prob = (inner_prob,tag)

            ret.append(prob[1])
        return ret

    def viterbi_tags(self, tokens):
        tags = list(self.em_probs.keys())

        #initialization
        #delta structure - {time step : {curr_tag : probability}}
        initial_delta = {}
        for tag in tags:
            if tokens[0] in self.em_probs[tag]:
                initial_delta[tag] = self.init_probs[tag] * self.em_probs[tag][tokens[0]]
            else:
                initial_delta[tag] = self.init_probs[tag] * self.em_probs[tag]["<UNK>"]
        delta = {0 : initial_delta}

        #Backtracer
        #backtrace structure - {time step : {curr_tag : prev_tag}}
        tracer = {}

        #Iteration
        for i in range(1,len(tokens)):
            for cur_tag in tags:
                best_prob = 0
                best_prev_tag = None
                for prev_tag in tags:
                    prob = delta[i-1][prev_tag] * self.trans_probs[prev_tag][cur_tag]
                    #Update the best
                    if prob > best_prob:
                        best_prob = prob
                        best_prev_tag = prev_tag

                #Update delta[i][tag]
                if i not in delta:
                    delta[i] = {}
                if tokens[i] in self.em_probs[cur_tag]:
                    delta[i][cur_tag] = best_prob * self.em_probs[cur_tag][tokens[i]]
                else:
                    delta[i][cur_tag] = best_prob * self.em_probs[cur_tag]["<UNK>"]

                #Keep track of previous best tags
                if i not in tracer:
                    tracer[i] = {}
                tracer[i][cur_tag] = best_prev_tag

        #Backtrace
        #First, iterate through delta to find the maximum probability a.k.a. the final (ending) state
        final_probability = 0
        final_state = ""
        for tag in tags:
            if final_probability < delta[len(tokens) - 1][tag]:
                final_probability = delta[len(tokens) - 1][tag]
                final_state = tag

        #Work backwards from maximum-yielding edges logged in tracer{}
        states = []
        curr_state = final_state
        for i in range(len(tokens) - 1, -1, -1):
            states.insert(0,curr_state)
            if (not i):
                break
            curr_state = tracer[i][curr_state]

        return states

#Testing function
def test():
    c = load_corpus("brown-corpus.txt")
    print("Q1:\t----")
    print(c[1402] == [('It', 'PRON'), ('made', 'VERB'), ('him', 'PRON'), ('human', 'NOUN'), ('.', '.')])
    print(c[1799] == [('The', 'DET'), ('prospects', 'NOUN'), ('look', 'VERB'), ('great', 'ADJ'), ('.', '.')])
    t = Tagger(c)
    print("Q2:\t----")
    print(t.most_probable_tags(["The","man","walks","."]) == ['DET', 'NOUN', 'VERB', '.'])
    print(t.most_probable_tags(["The","blue","bird","sings"]) == ['DET', 'ADJ', 'NOUN', 'VERB'])
    print("Q3:\t----")
    print("I am waiting to reply")
    s = "I am waiting to reply".split()
    print(t.most_probable_tags(s))
    print(t.viterbi_tags(s))
    print("I saw the play")
    s = "I saw the play".split()
    print(t.most_probable_tags(s))
    print(t.viterbi_tags(s))

############################################################
# Section 2: Feedback
############################################################

feedback_question_1 = """
I spent about 10 hours on this assignment.
"""

feedback_question_2 = """
The hardest part was understanding the Viterbi algorithm, and the second hardest was structuring the data.
"""

feedback_question_3 = """
I enjoy language processing in general, so it was cool to see how one can accomplish this with this specific algorithm.
"""
