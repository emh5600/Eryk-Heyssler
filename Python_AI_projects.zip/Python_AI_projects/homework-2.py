############################################################
# CMPSC 442: Homework 2
############################################################

student_name = "Eryk Heyssler"

############################################################
# Imports
############################################################

# Include your imports here, if any are used.
from math import factorial
import random
from copy import deepcopy

############################################################
# Section 1: N-Queens
############################################################

def num_placements_all(n):
    total_squares = n * n
    comb = 1
    for i in range(n):
        comb = (total_squares-i) * comb
    return comb

def num_placements_one_per_row(n):
    return factorial(n)

def n_queens_valid(board):
    x_row = 0
    for x_col in board:
        y_row = x_row + 1
        for y_col in (board[y_row:]):
            if (abs(y_row - x_row) == abs(y_col- x_col) or y_col == x_col):
                return False
            y_row = y_row + 1
        x_row = x_row + 1
    return True

def n_queens_helper(n,board):
    if (n == len(board)):
        return board
    else:
        for i in range(n):
            new_board = board + [i]
            if (n_queens_valid(new_board)):
                yield new_board

def n_queens_solutions(n):
    for k in range(n):
        q = [[k]]
        i = 0
        while i < n-1:
            temp_list = []
            for elem in q:
                temp_list = temp_list + list(n_queens_helper(n,elem))
            q = deepcopy(temp_list)
            i = i + 1
        yield from q


############################################################
# Section 2: Lights Out
############################################################

class LightsOutPuzzle(object):

    def __init__(self, board):
        self.board = board
        self.row_dim = len(board)
        self.col_dim = len(board[0])

    def get_board(self):
        return self.board

    def perform_move(self, row, col):
        self.board[row][col] = not self.board[row][col]

        #left
        if (col != 0):
            self.board[row][col-1] = not self.board[row][col-1]

        #right
        if (col != self.col_dim-1):
            self.board[row][col+1] = not self.board[row][col+1]

        #up
        if (row != 0):
            self.board[row-1][col] = not self.board[row-1][col]

        #down
        if (row != self.row_dim-1):
            self.board[row+1][col] = not self.board[row+1][col]

    def scramble(self):
        for row in range(self.row_dim):
            for col in range(self.col_dim):
                if (random.random() < 0.5):
                    self.perform_move(row,col)

    def is_solved(self):
        for row in range(self.row_dim):
            for col in range(self.col_dim):
                if (self.board[row][col]):
                    return False
        return True

    def copy(self):
        return LightsOutPuzzle(deepcopy(self.board))

    def successors(self):
        for row in range(self.row_dim):
            for col in range(self.col_dim):
                new_p = self.copy()
                new_p.perform_move(row, col)
                yield ((row,col),new_p)

    def find_solution(self):
        #maps (LightsOutPuzzle objects,move) : LightsOutPuzzle objects
        states = {(self,()):()}
        #how each key is represented
        boardKey = (self,())
        #the final boardkey that represents a solved solution
        solved = ()

        if self.is_solved():
            return []

        #holds LightsOutPuzzleObjects
        frontier = [self]

        while True:
            for node in frontier:
                for move,LO_obj in node.successors():

                    boardKey = (LO_obj,move)

                    #add to states
                    if any(s[0].get_board() == boardKey[0].get_board() for s in states):
                        continue
                    else:
                        states[boardKey] = node
                        if boardKey[0].is_solved():
                            frontier = []
                            solved = boardKey
                            break

                    #add to frontier
                    if any(s.get_board() == boardKey[0].get_board() for s in frontier):
                        continue
                    else:
                        frontier.append(boardKey[0])

                if frontier == []:
                    break

            if solved != () or frontier == []:
                break
            else:
                return None

        #find solution; this assumes that there is one.
        solution = []
        while True:
            if boardKey[0].get_board() == self.get_board():
                solution.reverse()
                return solution
            solution.append(boardKey[1])
            next_board = states[boardKey]
            for s in states:
                if s[0] == next_board:
                    boardKey = s
                    break

def create_puzzle(rows, cols):
    return LightsOutPuzzle([[False for i in range(cols)] for k in range(rows)])

############################################################
# Section 3: Linear Disk Movement
############################################################
class DiskPuzzle(object):
    def __init__(self, board):
        self.board = board

    def get_board(self):
        return self.board
    #movement functions, forward and back, 1 step, 2 step
    def perform_1move_fwd(self, index,token):
        if index + 1 > len(self.board) - 1 or self.board[index] == -1:
            return False

        if self.board[index+1] != -1:
            return False
        else:
            self.board[index+1] = token
            self.board[index] = -1
        return True

    def perform_2move_fwd(self,index,token):
        if index + 2 > len(self.board) - 1 or self.board[index] == -1:
            return False

        if self.board[index+2] != -1:   #there exists a token there already
            return False
        elif self.board[index+1] != -1:
            self.board[index+2] = token
            self.board[index] = -1
        return True

    def perform_1move_back(self, index,token):
        if index - 1 < 0 or self.board[index] == -1:
            return False

        if self.board[index-1] != -1:
            return False
        else:
            self.board[index-1] = token
            self.board[index] = -1
        return True

    def perform_2move_back(self,index,token):
        if index - 2 < 0 or self.board[index] == -1:
            return False

        if self.board[index-2] != -1:   #there exists a token there already
            return False
        elif self.board[index-1] != -1:
            self.board[index-2] = token
            self.board[index] = -1
        return True

    def is_equal(self,reversed_board):
        if reversed_board == self.get_board():
            return True
        return False

    def copy(self):
        return DiskPuzzle(deepcopy(self.board))

    # yield all possibilities of moves
    def successors(self):
        for i in range(len(self.get_board())):
            new_1 = self.copy()
            new_2 = self.copy()
            new_3 = self.copy()
            new_4 = self.copy()
            if (new_1.perform_1move_fwd(i,self.get_board()[i])):
                yield ((i,i+1),new_1)
            if (new_2.perform_2move_fwd(i,self.get_board()[i])):
                yield ((i,i+2),new_2)
            if (new_3.perform_1move_back(i,self.get_board()[i])):
                yield ((i,i+1),new_3)
            if (new_4.perform_2move_back(i,self.get_board()[i])):
                yield ((i,i+2),new_4)

    def find_solution(self,reversed_board):
        #maps (DiskPuzzle objects,move) : DiskPuzzle objects
        states = {(self,()):()}
        #how each key is represented
        boardKey = (self,())
        #the final boardkey that represents a solved solution
        solved = ()

        if self.is_equal(reversed_board):
            return []

        #holds diskPuzzle objects
        frontier = [self]

        while True:
            for node in frontier:
                for move,LO_obj in node.successors():

                    boardKey = (LO_obj,move)

                    #add to states
                    if any(s[0].get_board() == boardKey[0].get_board() for s in states):
                        continue
                    else:
                        states[boardKey] = node
                        if boardKey[0].is_equal(reversed_board):
                            frontier = []
                            solved = boardKey
                            break

                    #add to frontier
                    if any(s.get_board() == boardKey[0].get_board() for s in frontier):
                        continue
                    else:
                        frontier.append(boardKey[0])

                if frontier == []:
                    break

            if solved != () or frontier != []:
                break
            else:
                return None

        #find solution; this assumes that there is one.
        solution = []
        while True:
            if boardKey[0].get_board() == self.get_board():
                solution.reverse()
                return solution
            solution.append(boardKey[1])
            next_board = states[boardKey]
            for s in states:
                if s[0] == next_board:
                    boardKey = s
                    break


def create_identical_disk_puzzle(length,n):
    board = []
    for i in range(length):
        if n > 0:
            board.append(1)
        else:
            board.append(-1)
        n = n - 1
    #create the disk puzzle object
    p = DiskPuzzle(board)
    #create the reversed_board object
    reversed_board = board[::-1]
    #return solution
    solution = p.find_solution(reversed_board)

    return list(solution)

def create_distinct_disk_puzzle(length,n):
    board = []
    for i in range(length):
        if n > 0:
            board.append(i)
        else:
            board.append(-1)
        n = n - 1
    #create the disk puzzle object
    p = DiskPuzzle(board)
    #create the reversed_board object
    reversed_board = board[::-1]
    #return solution
    solution = p.find_solution(reversed_board)
    return list(solution)

def solve_identical_disks(length, n):
    return create_identical_disk_puzzle(length,n)

def solve_distinct_disks(length, n):
    return create_distinct_disk_puzzle(length,n)


############################################################
# Section 4: Feedback
############################################################

feedback_question_1 = """
I worked on this for about 7 hours.
"""

feedback_question_2 = """
I had trouble with the n_queens DFS problem;
I'm not so sure if my solution is even DFS.
It also took me a long time to realize that I can use python dictionaries to make a graph, where each relationship is an edge.
"""

feedback_question_3 = """
I liked how, once I finished and understood problem 2, problem 3 took me only a fraction of the time, since it is largely the same code, with minor differences
in conditions -- still a BFS nonetheless. If I were the instructor, I would maybe provide a simple graph class or something that we can use
for implementing BFS or DFS. In all fairness though, I can see why it's important to give students the freedom to explore other options (i.e. dictionaries).
"""
