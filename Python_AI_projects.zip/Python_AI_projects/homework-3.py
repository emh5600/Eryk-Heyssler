############################################################
# CMPSC 442: Homework 3
############################################################

student_name = "Eryk Heyssler"

############################################################
# Imports
############################################################

# Include your imports here, if any are used.
from random import choice as rchoice
from copy import deepcopy
from queue import PriorityQueue
from math import sqrt
from math import inf

############################################################
# Section 1: Tile Puzzle
############################################################

def create_tile_puzzle(rows, cols):
    i = 0
    board = []
    for r in range(rows):
        row = []
        for c in range(cols):
            if (r == rows - 1 and c == cols - 1):
                i = 0
            else:
                i = i + 1

            row.append(i)
        board.append(row)

    return TilePuzzle(board)

class TilePuzzle(object):
    
    # Required
    def __init__(self, board):
        self.board = board
        self.rownum = len(board)
        self.colnum = len(board[0])

        self.g = 0  #manhattan distance of parent node + distance between the nodes
        self.h = 0  #manhattan distance of a specific node
        self.f = 0  #f(n) = g(n) + h(n)
        self.solutionpath = [] #set of moves that describes how to get to the goal state

    def get_board(self):
        return self.board

    #Return coordinates of the empty (0) tile.
    def find_empty_tile(self):
        for r in range(self.rownum):
            for c in range(self.colnum):
                if self.board[r][c] == 0:
                    return (r,c)

        return (-1,-1)

    def perform_move(self, direction):
        coords = self.find_empty_tile()

        if direction == "up":
            #If the 0 is in the top row, return false, otherwise return true
            if coords[0] == 0:
                return False
            else:
                temp = self.board[coords[0] - 1][coords[1]]
                self.board[coords[0] - 1][coords[1]] = 0
                self.board[coords[0]][coords[1]] = temp
                return True
        elif direction == "down":
            #If the 0 is in the last row, return false, otherwise return true
            if coords[0] == self.rownum - 1:
                return False
            else:
                temp = self.board[coords[0] + 1][coords[1]]
                self.board[coords[0] + 1][coords[1]] = 0
                self.board[coords[0]][coords[1]] = temp
                return True
        elif direction == "left":
            #If the 0 is in the leftmost column, return false, otherwise return true
            if coords[1] == 0:
                return False
            else:
                temp = self.board[coords[0]][coords[1] - 1]
                self.board[coords[0]][coords[1] - 1] = 0
                self.board[coords[0]][coords[1]] = temp
                return True
        elif direction == "right":
            #If the 0 is in the rightmost column, return false, otherwise return true
            if coords[1] == self.colnum -1:
                return False
            else:
                temp = self.board[coords[0]][coords[1] + 1]
                self.board[coords[0]][coords[1] + 1] = 0
                self.board[coords[0]][coords[1]] = temp
                return True
        else:
            return False

    def scramble(self, num_moves):
        moves_list = ["up","down","left","right"]
        for i in range(num_moves):
            self.perform_move(rchoice(moves_list))

    def is_solved(self):
        i = 1
        for r in range(self.rownum):
            for c in range(self.colnum):
                if (r == self.rownum - 1 and c == self.colnum - 1):
                    if self.board[r][c] == 0:
                        return True
                else:
                    if self.board[r][c] != i:
                        return False
                    i = i + 1
        return False

    def copy(self):
        return deepcopy(self.board)

    def successors(self):
        moveslist = ["up","down","left","right"]
        for move in moveslist:
            temp = TilePuzzle(self.copy())
            if (temp.perform_move(move)):
                yield (move,temp)


    #Recursive helper function for iddfs
    # yield all solutions to the current board of length no more than limit
    # Each solution is a continuation of the provided move list

    def idffs_helper(self,limit,moves):
        #stop condition, otherwise we do not return anything
        if self.is_solved() and limit == 0:
            yield moves

        if limit > 0:
            #generate the children of the current node
            for m, child in self.successors():
                _moves = deepcopy(moves)
                _moves.append(m)
                # recursive call on each child to perform the depth first search
                yield from child.idffs_helper(limit-1,_moves)

    # Required
    def find_solutions_iddfs(self):
        limit = 0
        #Run the helper function, increasing the limit by 1 every time that we do not find a solution
        while True:
            _sol = self.idffs_helper(limit, [])
            sol = list(_sol)
            if (sol):
                yield from sol
                break
            else:
                limit += 1

    def ManhattanDistance(self):
        mdist = 0
        for r in range(self.rownum):
            for c in range(self.colnum):
                # r1 = row where curr number should be
                # c1 = col where curr number should be
                currnum = self.board[r][c]

                if currnum == 0:
                    r1 = self.rownum -1
                    c1 = self.colnum -1
                else:
                    if (currnum % self.colnum):
                        r1 = (currnum + self.colnum - (currnum % self.colnum)) // (self.colnum) - 1
                    else:
                        r1 = currnum // (self.colnum) - 1

                    if (currnum % self.colnum):
                        c1 = currnum % self.colnum - 1
                    else:
                        c1 = self.colnum - 1

                mdist += abs(r1 - r) + abs(c1 - c)
        return mdist

    # Required
    def find_solution_a_star(self):
        Q = PriorityQueue() #Open list
        closed = []  #Closed list

        self.g = 0
        self.h = self.ManhattanDistance()
        self.f = self.g + self.h

        i = 0 #Numbers each unique node, needed for PriorityQueue functionality

        Q.put((self.h,i,self)) #Node[0] - Manhattan Distance ; Node[1] - Unique ID ; Node[2] - TilePuzzle object

        while not Q.empty():
            #Find the node with the least f on the open list
            currentNode = Q.get()
            if (currentNode[2].is_solved()):
                return currentNode[2].solutionpath  # backtrace

            #Generate currentNodes neighbors
            for move, child in currentNode[2].successors():
                #Calculate distances
                child.g = currentNode[2].g + 1
                child.h = child.ManhattanDistance()
                child.f = child.g + child.h

                #Return if a solution is found
                if child.is_solved():
                    child.solutionpath = currentNode[2].solutionpath + [move]
                    return child.solutionpath

                #If a node with the same position as child, and a lower distance is in the queue/closed list, don't add it
                flag = 1
                for node in closed:
                    if (child.get_board() == node[2].get_board() and node[2].f < child.f):
                            flag = 0
                            break
                if (flag): #no point in checking the queue if flag is 0
                    for node in Q.queue:
                        if (child.get_board() == node[2].get_board() and node[2].f < child.f):
                                flag = 0
                                break
                if (flag):
                    i += 1
                    Q.put((child.f,i,child))
                    child.solutionpath = currentNode[2].solutionpath + [move]

            closed.append(currentNode)

############################################################
# Section 2: Grid Navigation
############################################################

class GridPuzzle(object):

    # Required
    def __init__(self, board, start, goal):
        self.board = board

        self.start = start
        self.location = start
        self.goal = goal

        self.rownum = len(board)
        self.colnum = len(board[0])

        self.g = 0  # manhattan distance of parent node + distance between the nodes
        self.h = 0  # manhattan distance of a specific node
        self.f = 0  # f(n) = g(n) + h(n)
        self.solutionpath = []  # set of moves that describes how to get to the goal state

    def is_solved(self):
        if self.location == self.goal:
            return True
        return False

    def successors(self):
        r = self.location[0]
        c = self.location[1]

        #all 'up' moves
        if (r != 0):
            if (not self.board[r-1][c]):
                yield (r-1,c)                                           #UP
            if (c != 0 and not self.board[r-1][c-1]):
                yield (r-1,c-1)                                         #UP-LEFT
            if (c != self.colnum - 1 and not self.board[r-1][c+1]):
                yield (r-1,c+1)                                         #UP-RIGHT
        #all side moves
        if (c != 0):
            if (not self.board[r][c-1]):
                yield (r,c-1)                                           #LEFT
        if (c != self.colnum - 1):
            if (not self.board[r][c+1]):
                yield (r,c+1)                                           #RIGHT
        #all down moves
        if (r != self.rownum - 1):
            if (not self.board[r+1][c]):
                yield (r+1,c)                                           #DOWN
            if (c != 0 and not self.board[r+1][c-1]):
                yield (r+1,c-1)                                         #DOWN-LEFT
            if (c != self.colnum -1 and not self.board[r+1][c+1]):
                yield (r+1,c+1)                                         #DOWN-RIGHT

    def ManhattanDistance(self):
        #straight line distance between two points
        return sqrt( (self.location[0]-self.goal[0])**2 + (self.location[1]-self.goal[1])**2 )

    # Required
    def find_solution_a_star(self):
        Q = PriorityQueue()  # Open list
        closed = []  # Closed list

        self.g = 0
        self.h = self.ManhattanDistance()
        self.f = self.g + self.h

        i = 0  # Numbers each unique node, needed for PriorityQueue functionality

        Q.put((self.h, i, self))  # Node[0] - Manhattan Distance ; Node[1] - Unique ID ; Node[2] - TilePuzzle object

        while not Q.empty():
            # Find the node with the least f on the open list
            currentNode = Q.get()
            if (currentNode[2].is_solved()):
                return currentNode[2].solutionpath  # backtrace

            # Generate currentNodes neighbors
            for move in currentNode[2].successors():
                child = GridPuzzle(self.board,move,self.goal)

                child.g = currentNode[2].g + 1
                child.h = child.ManhattanDistance()
                child.f = child.g + child.h

                # Return if a solution is found
                if child.is_solved():
                    child.solutionpath = currentNode[2].solutionpath + [move]
                    return [(0,0)] + child.solutionpath

                # If a node with the same position as child, and a lower distance is in the queue/closed list, don't add it
                flag = 1
                for node in closed:
                    if (child.location == node[2].location and node[2].f < child.f):
                        flag = 0
                        break
                if (flag):  # no point in checking the queue if flag is 0
                    for node in Q.queue:
                        if (child.location == node[2].location and node[2].f < child.f):
                            flag = 0
                            break
                if (flag):
                    i += 1
                    Q.put((child.f, i, child))
                    child.solutionpath = currentNode[2].solutionpath + [move]

            closed.append(currentNode)
        return None

def find_path(start, goal, scene):
    b = GridPuzzle(scene,start,goal)
    return b.find_solution_a_star()

############################################################
# Section 3: Linear Disk Movement, Revisited
############################################################
class DiskPuzzle(object):
    def __init__(self, board):
        self.board = board

        self.g = 0  # manhattan distance of parent node + distance between the nodes
        self.h = 0  # manhattan distance of a specific node
        self.f = 0  # f(n) = g(n) + h(n)
        self.solutionpath = []  # set of moves that describes how to get to the goal state

    def get_board(self):
        return self.board

    #movement functions, forward and back, 1 step, 2 step
    def perform_1move_fwd(self, index):
        if index == len(self.board) - 1 or self.board[index] == -1:
            return False

        if self.board[index+1] != -1:
            return False
        else:
            token = self.board[index]
            self.board[index+1] = token
            self.board[index] = -1
            return True

    def perform_2move_fwd(self,index):
        if index + 2 > len(self.board) - 1 or self.board[index] == -1:
            return False

        if self.board[index+2] != -1:   #there exists a token there already
            return False
        elif self.board[index+1] != -1: #can only hop over when theres a token in between
            token = self.board[index]
            self.board[index+2] = token
            self.board[index] = -1
            return True
        else:
            return False

    def perform_1move_back(self, index):
        if index - 1 < 0 or self.board[index] == -1:
            return False

        if self.board[index-1] != -1:
            return False
        else:
            token = self.board[index]
            self.board[index-1] = token
            self.board[index] = -1
            return True

    def perform_2move_back(self,index):
        if index - 2 < 0 or self.board[index] == -1:
            return False

        if self.board[index-2] != -1:   #there exists a token there already
            return False
        elif self.board[index-1] != -1:
            token = self.board[index]
            self.board[index-2] = token
            self.board[index] = -1
            return True
        else:
            return False

    def is_solved(self,solutionBoard):
        if solutionBoard == self.get_board():
            return True
        return False

    def copy(self):
        return DiskPuzzle(deepcopy(self.board))

    # yield all possibilities of moves
    def successors(self):
        for i in range(len(self.get_board())):
            if self.get_board()[i] != -1:
                new_1 = self.copy()
                new_2 = self.copy()
                new_3 = self.copy()
                new_4 = self.copy()
                if (new_1.perform_1move_fwd(i)):
                    yield ((i,i+1),new_1)
                if (new_2.perform_2move_fwd(i)):
                    yield ((i,i+2),new_2)
                if (new_3.perform_1move_back(i)):
                    yield ((i,i+1),new_3)
                if (new_4.perform_2move_back(i)):
                    yield ((i,i+2),new_4)

    #Calculate the manhattan distance
    def ManhattanDistance(self):
        mandist = 0
        for i in range(len(self.board)):
            elem = self.board[i]
            if (elem != -1):
                mandist += abs(len(self.board) - i - elem - 1)
        return mandist

    def perform_move_wrapper(self,indextup):
        if indextup[0] - indextup[1] == -1:
            return self.perform_1move_fwd(indextup[0])
        elif indextup[0] - indextup[1] == -2:
            return self.perform_2move_fwd(indextup[0])
        elif indextup[0] - indextup[1] == 1:
            return self.perform_1move_back(indextup[0])
        elif indextup[0] - indextup[1] == 2:
            return self.perform_2move_back(indextup[0])

    def find_solution_astar(self,solutionBoard):
        Q = PriorityQueue()  # Open list
        closed = []  # Closed list

        self.g = 0
        self.h = self.ManhattanDistance()
        self.f = self.g + self.h

        i = 0  # Numbers each unique node, needed for PriorityQueue functionality

        Q.put((self.h, i, self))  # Node[0] - Manhattan Distance ; Node[1] - Unique ID ; Node[2] - DiskPuzzle object

        while not Q.empty():
            # Find the node with the least f on the open list
            currentNode = Q.get()
            if (currentNode[2].is_solved(solutionBoard)):
                return currentNode[2].solutionpath  # backtrace

            # Generate currentNodes neighbors
            for move, child in currentNode[2].successors():

                child.g = currentNode[2].g + 1
                child.h = child.ManhattanDistance()
                child.f = child.g + child.h

                # Return if a solution is found
                if child.is_solved(solutionBoard):
                    child.solutionpath = currentNode[2].solutionpath + [move]
                    return child.solutionpath

                # If a node with the same position as child, and a lower distance is in the queue/closed list, don't add it
                flag = 1
                for node in closed:
                    if (child.get_board() == node[2].get_board() and node[2].f < child.f):
                        flag = 0
                        break
                if (flag):  # no point in checking the queue if flag is 0
                    for node in Q.queue:
                        if (child.get_board() == node[2].get_board() and node[2].f < child.f):
                            flag = 0
                            break
                if (flag):
                    i += 1
                    Q.put((child.f, i, child))
                    child.solutionpath = currentNode[2].solutionpath + [move]

            closed.append(currentNode)

def solve_distinct_disks(length, n):
    board = []
    for i in range(length):
        if n > 0:
            board.append(i)
        else:
            board.append(-1)
        n = n - 1
    # create the disk puzzle object
    p = DiskPuzzle(board)
    # create the reversed_board object
    reversed_board = board[::-1]
    # return solution
    solution = p.find_solution_astar(reversed_board)
    return solution

############################################################
# Section 4: Dominoes Game
############################################################

def create_dominoes_game(rows, cols):
    b = []
    for r in range(rows):
        row = []
        for c in range(cols):
            row.append(False)
        b.append(row)
    return DominoesGame(b)

class DominoesGame(object):

    # Required
    def __init__(self, board):
        self.board = board
        self.numrows = len(board)
        self.numcols = len(board[0])

        self.vertical = None    #Indicates the current boards move
        self.playerVertical = None #Indicates the player for whom we are trying to find the best move
        self.numNodesAB = 0 #Number of nodes traversed in the AB-search algorithm by each node to reach bestMove
        self.bestMove = ()      #the current best move to execute

    def get_board(self):
        return self.board

    def reset(self):
        for r in range(self.numrows):
            for c in range(self.numcols):
                self.board[r][c] = False

    def is_legal_move(self, row, col, vertical):
        #Trying to do a vertical move
        if (vertical):
            if ((0 <= row < self.numrows - 1) and (0 <= col <= self.numcols - 1) and
                    not self.board[row][col] and not self.board[row+1][col]):
                return True
            else:
                return False
        # Trying to do a horizontal move
        else:
            if ((0 <= row <= self.numrows - 1) and (0 <= col < self.numcols - 1) and
            not self.board[row][col] and not self.board[row][col+1]):
                return True
            else:
                return False

    def legal_moves(self, vertical):
        for r in range(self.numrows):
            for c in range(self.numrows):
                if self.is_legal_move(r,c,vertical):
                    yield((r,c))

    def perform_move(self, row, col, vertical):
        if self.is_legal_move(row,col,vertical):
            self.board[row][col] = True
            if (vertical):
                self.board[row + 1][col] = True
            else:
                self.board[row][col + 1] = True

    def game_over(self, vertical):
        if list(self.legal_moves(vertical)):
            return False
        return True

    def copy(self):
        return DominoesGame(deepcopy(self.board))

    def successors(self, vertical):
        for move in list(self.legal_moves(vertical)):
            cop = self.copy()
            cop.perform_move(move[0],move[1],vertical)
            yield (move, cop)

    def get_random_move(self, vertical):
        return rchoice(list(self.legal_moves(vertical)))

    def calculate_heuristic(self):
        return len(list((self.legal_moves(self.playerVertical)))) - len(list((self.legal_moves(not self.playerVertical))))

    def max_value(self, alpha, beta,limit):
        #Check if we are in a terminal condition
        if (limit == 0 or self.game_over(self.vertical)):
            v = self.calculate_heuristic()
            self.numNodesAB += 1
            return v

        v = -inf
        for move, child in self.successors(self.vertical):
            #before calling the other function, initialize the child
            child.vertical = not self.vertical
            child.playerVertical = self.playerVertical
            #choose the maximum v, and update the move accordingly
            _v = child.min_value(alpha,beta,limit - 1)
            if (v < _v):
                v = _v
                self.bestMove = move

            self.numNodesAB += child.numNodesAB
            #alpha/beta pruning
            if v >= beta:
                return v
            alpha = max(alpha,v)
        return v

    def min_value(self, alpha, beta,limit):
        # Check if we are in a terminal condition
        if (limit == 0 or self.game_over(self.vertical)):
            v = self.calculate_heuristic()
            self.numNodesAB += 1
            return v

        v = inf
        for move, child in self.successors(self.vertical):
            # before calling the other function, initialize the child
            child.vertical = not self.vertical
            child.playerVertical = self.playerVertical

            # choose the minimum v, and update the move accordingly
            _v = child.max_value(alpha, beta,limit - 1)
            if (v > _v):
                v = _v
                self.bestMove = move

            self.numNodesAB += child.numNodesAB
            # alpha/beta pruning
            if v <= alpha:
                return v
            beta = min(alpha, v)
        return v

    # ALPHA-BETA-SEARCH
    def get_best_move(self, vertical, limit):
        self.vertical = vertical
        self.playerVertical = vertical
        self.numNodesAB = 0

        v = self.max_value(-inf, inf,limit)
        return (self.bestMove,v,self.numNodesAB) # return 3-elem tuple with the (best move, value, number nodes traversed)

############################################################
# Section 5: Feedback
############################################################

feedback_question_1 = """
About 10 hours.
"""

feedback_question_2 = """
The hardest parts were:
1) Figuring out a good method for backtracking the A* algorithm - though the solution seems 
very trivial now, I was using dictionaries before to represent edges, and I wasted a LOT of time doing that.
2) Passing parameters between the two functions of the alpha-beta search. It took a lot of time for me to realize
that the heuristic always depends on the player who called the get_best_move function, and not on which
'state' the board is in during the algorithm (min or max).
"""

feedback_question_3 = """
Despite the difficulties in my understanding of the algorithms and figuring out a good representation for them,
this was a fine assignment and I would not change anything about it.
"""
