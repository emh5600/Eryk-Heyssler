############################################################
# CMPSC 442: Homework 1
############################################################

student_name = "Eryk Heyssler"

############################################################
# Section 1: Python Concepts
############################################################

python_concepts_question_1 = """
Strong typing means that every object has a fixed type, meaning
one cannot do operations with incompatible types.
The example below would throw an error.
ex. >>x = 5
    >>y = "abc"
    >>x + y 

Dynamic typing means that variables come into existence when first assigned.
This means that a variables type is determined based on what it is assigned to.
ex. >>x = 5
    >>print(x + 1)
    >>x = "abc"
    >>print(x)
The example above will first print 6, followed by abc.
"""

python_concepts_question_2 = """
The issue with this is that lists are not hashable, therefore an error is thrown.
A solution to this would be to use tuples as keys, since they are hashable:
points_to_names = {(0, 0): "home", (1, 2): "school", (-1, 1): "market"}
"""

python_concepts_question_3 = """
Option 2 is faster.
With every iteration of the for loop in the first function, a copy of the
entire string is made, therefore more memory must be allocated.
"""

############################################################
# Section 2: Working with Lists
############################################################

def extract_and_apply(l, p, f):
    return [f(x) for x in l if p(x)]

def concatenate(seqs):
    return [y for x in seqs for y in x]

def transpose(matrix):
    return [[row[i] for row in matrix] for i in range(len(matrix[0]))]

############################################################
# Section 3: Sequence Slicing
############################################################

def copy(seq):
    return seq[:]

def all_but_last(seq):
    return seq[:-1]

def every_other(seq):
    return seq[0::2]

############################################################
# Section 4: Combinatorial Algorithms
############################################################

def prefixes(seq):
    for n in range(len(seq)+1):
        yield seq[:n]

def suffixes(seq):
    for n in range(len(seq)+1,0,-1):
        yield seq[len(seq)+1-n:n+1]

def slices(seq):
    n = len(seq)
    for i in range(n):
        for k in range(i,n):
            yield(seq[i:k+1])

############################################################
# Section 5: Text Processing
############################################################

def normalize(text):
    return text[:].lower().strip()

def no_vowels(text):
    vowelsList = ['a','e','i','o','u']
    return "".join([text[i] for i in range(len(text)) if text[i].lower() not in vowelsList])

def digits_to_words(text):
    digitDict = {'0' : 'zero',
                 '1' : 'one',
                 '2' : 'two',
                 '3' : 'three',
                 '4' : 'four',
                 '5' : 'five',
                 '6' : 'six',
                 '7' : 'seven',
                 '8' : 'eight',
                 '9' : 'nine'}

    return " ".join(digitDict[text[i]] for i in range(len(text)) if text[i].isnumeric())

def to_mixed_case(name):
    strippedName = name[:].strip('_')

    mixedCaseName = []
    i = 0
    while i < len(strippedName):
        if strippedName[i] == '_':
            i = i + 1
            if (strippedName[i] != '_'):
                mixedCaseName.append(strippedName[i].upper())
                i = i + 1
        else:
            mixedCaseName.append(strippedName[i].lower())
            i = i + 1

    return "".join(mixedCaseName)

############################################################
# Section 6: Polynomials
############################################################

class Polynomial(object):

    def __init__(self, polynomial):
        self.polynomial = tuple(polynomial)

    def get_polynomial(self):
        return self.polynomial

    def __neg__(self):
        negPolynomial = []
        for i in self.polynomial:
            tup = (-i[0],i[1])
            negPolynomial.append(tup)
        return Polynomial(negPolynomial)

    def __add__(self, other):
        added = list(self.polynomial)
        for i in other.get_polynomial():
            added.append(i)
        return Polynomial(added)

    def __sub__(self, other):
        return self.__add__(other.__neg__())

    def __mul__(self, other):
        first = (self.get_polynomial()[0][0] * other.get_polynomial()[0][0], self.get_polynomial()[0][1] + other.get_polynomial()[0][1])
        outer = (self.get_polynomial()[0][0] * other.get_polynomial()[1][0], self.get_polynomial()[0][1] + other.get_polynomial()[1][1])
        inner = (self.get_polynomial()[1][0] * other.get_polynomial()[0][0], self.get_polynomial()[1][1] + other.get_polynomial()[0][1])
        last = (self.get_polynomial()[1][0] * other.get_polynomial()[1][0], self.get_polynomial()[1][1] + other.get_polynomial()[1][1])
        return Polynomial([first,outer,inner,last])

    def __call__(self, x):
        return sum(self.get_polynomial()[i][0] * x**self.get_polynomial()[i][1] for i in range(len(self.get_polynomial())))

    def simplify(self):
        simplified = []
        flag = 0
        for i in self.get_polynomial():
            flag = 0
            if simplified:
                n = len(simplified)
                for k in range(n):
                    if (i[1] == simplified[k][1]):
                        simplified[k] = (i[0] + simplified[k][0],i[1])
                        flag = 1
                        break
                if not flag:
                    simplified.append(i)
            else:
                simplified.append(i)
        for i in simplified:
            if i[0] == 0 and i[1] != 0:
                simplified.remove(i)
        if (len(simplified) > 1) and ((0,0) in simplified):
            simplified.remove((0,0))
        simplified.sort(reverse = True,key= lambda x: x[1])
        self.__init__(simplified)


    def __str__(self):
        eqlist = []
        for i in self.get_polynomial():
            for k in self._str_helper(i):
                eqlist.append(k)

        if eqlist[0] == '+':
            eqlist.pop(0)
        else:
            eqlist[1] = eqlist[0] + eqlist[1]
            eqlist.pop(0)
        return ' '.join(eqlist)

    def _str_helper(self,tup):
        eq = [''] * 4 # of maximum length 5
        if tup[0] < 0:
            sign = '-'
        else:
            sign = '+'

        if tup[1] == 0:
            eq[0] = str(abs(tup[0]))
            return [sign,''.join(eq)]
        else:
            if abs(tup[0]) == 1:
                eq[1] = 'x'
            else:
                eq[0] = str(abs(tup[0]))
                eq[1] = 'x'
            if (tup[1] != 1):
                eq[2] = '^'
                eq[3] = str(tup[1])
        return [sign,''.join(eq)]

############################################################
# Section 7: Feedback
############################################################

feedback_question_1 = """
About 3 hours.
"""

feedback_question_2 = """
The most challenging part was the last two problems, and trying to figure out an efficient strategy for them.
There were no significant stumbling blocks.
"""

feedback_question_3 = """
I liked that the assignment was diverse and that each question was explained well i.e. there was little room for misinterpretation
as to what was to be done. Since this is the first assignment, and it was meant as more of a foundation for python fundamentals, there is nothing I would change.
"""
