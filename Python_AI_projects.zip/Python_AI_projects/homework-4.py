############################################################
# CMPSC442: Homework 4
############################################################

student_name = "Eryk Heyssler"

############################################################
# Imports
############################################################

# Include your imports here, if any are used.
import email
import math
import os
from queue import PriorityQueue

############################################################
# Section 1: Spam Filter
############################################################

def load_tokens(email_path):
    try:
        file = open(email_path)
        msg = email.message_from_file(file)
        iterator = email.iterators.body_line_iterator(msg)

        return [token for line in iterator for token in (line.split())]
    except:
        return None #File doesn't exist

def log_probs(email_paths, smoothing):
    countDict = {}
    tokenList = []

    #Find all tokens
    for path in email_paths:
        tokens = load_tokens(path)
        if (tokens != None): #Making sure file exists
            tokenList += tokens

    #Count the number of occurences of each token
    for token in tokenList:
        if token in countDict:
            countDict[token] += 1
        else:
            countDict[token] = 1

    probDict = {}
    V = len(countDict)

    #Calculate w'
    countw_ = 0
    for token in countDict:
        countw_ += countDict[token]

    #Calculate the probability for each token
    for token in countDict:
        countw = countDict.get(token)
        probDict[token] = math.log((countw + smoothing) / (countw_ + smoothing*(V + 1)))

    probDict["<UNK>"] = math.log(smoothing / (countw_ + smoothing*(V + 1)))
    return probDict

class SpamFilter(object):

    def __init__(self, spam_dir, ham_dir, smoothing):
        numSpamFiles = len(os.listdir(spam_dir))
        numHamFiles = len(os.listdir(ham_dir))

        hamPaths = [ham_dir+"/ham%d" % i for i in range(1,numHamFiles)]
        spamPaths = [spam_dir+"/spam%d" % i for i in range(1,numSpamFiles)]

        self.spamProbDict = log_probs(spamPaths,smoothing) # P(w | (spam))
        self.hamProbDict = log_probs(hamPaths,smoothing)   # P(w | (~spam))
        self.spamProb = math.log(numSpamFiles / (numSpamFiles + numHamFiles)) #P(spam)
        self.hamProb = math.log(numHamFiles / (numSpamFiles + numHamFiles))   #P(~spam)
    
    def is_spam(self, email_path):
        words = load_tokens(email_path)
        if (words == None):
            return None # error if email_path is incorrect
        countDict = {}

        #Count the number of occurrences of each word
        for word in words:
            if word in countDict:
                countDict[word] += 1
            else:
                countDict[word] = 1

        spamProb = self.spamProb
        hamProb = self.hamProb

        #Probability that the msg is spam
        #We turn multiplication to addition bc. we're dealing with logs
        for word in countDict:
            if word in self.spamProbDict:
                spamProb += self.spamProbDict.get(word) * countDict.get(word)
            else:
                spamProb += self.spamProbDict.get("<UNK>")

        #Probability that the msg is not spam
        for word in countDict:
            if word in self.hamProbDict:
                hamProb += self.hamProbDict.get(word) * countDict.get(word)
            else:
                hamProb += self.hamProbDict.get("<UNK>")

        return spamProb >= hamProb

    def most_indicative_spam(self, n):
        q = PriorityQueue()

        for word in self.spamProbDict:
            if word in self.hamProbDict:
                # P(w)
                probOfWord = math.exp(self.spamProbDict.get(word)) + math.exp(self.hamProbDict.get(word))
                # log( P(w | spam) / P(w)) --> multiplied by -1 for the priority queue
                q.put((math.log(math.exp(self.spamProbDict.get(word)) / probOfWord) * -1, word))

        return [q.get()[1] for i in range(n)]

    def most_indicative_ham(self, n):
        q = PriorityQueue()

        for word in self.hamProbDict:
            if word in self.spamProbDict:
                # P(w)
                probOfWord = math.exp(self.hamProbDict.get(word)) + math.exp(self.spamProbDict.get(word))
                # log( P(w | ~spam) / P(w)) --> multiplied by -1 for the priority queue
                q.put((math.log(math.exp(self.hamProbDict.get(word)) / probOfWord) * -1, word))

        return [q.get()[1] for i in range(n)]


#--------------  Test Function --------------#
def test_spam_filter():
    ham_dir = "homework4_data/train/ham"
    spam_dir = "homework4_data/train/spam"
    numSpamFiles = len(os.listdir(spam_dir))
    numHamFiles = len(os.listdir(ham_dir))

    sf = SpamFilter(spam_dir, ham_dir, 1e-5)

    hamPaths = [ham_dir + "/ham%d" % i for i in range(1, numHamFiles)]
    spamPaths = [spam_dir + "/spam%d" % i for i in range(1, numSpamFiles)]

    hamCorrect = 0
    for hamMsg in hamPaths:
        flag = sf.is_spam(hamMsg)
        if (flag == True):
            print(hamMsg + " - " + str(flag))
        else:
            hamCorrect += 1
    print("HAM Correctness: " + str(hamCorrect) + "/" + str(numHamFiles))

    spamCorrect = 0
    for spamMsg in spamPaths:
        flag = sf.is_spam(spamMsg)
        if (flag == False):
            print(spamMsg + " - " + str(flag))
        else:
            spamCorrect += 1
    print("SPAM Correctness: " + str(spamCorrect) + "/" + str(numSpamFiles))

    return (spamCorrect+hamCorrect) / (numHamFiles + numSpamFiles) # return the accuracy
#------------- End Test Function ------------#

############################################################
# Section 2: Feedback
############################################################

feedback_question_1 = """
I spent approx. 5 hours on this assignment.
"""

feedback_question_2 = """
The only hard part was logarithmic algebra. Otherwise, the concepts were straight forward.
"""

feedback_question_3 = """
I liked the statistical/mathematical aspect of this assignment; I am excited to delve deeper into it in future assignments.
There was nothing in this homework that I would have changed, though it seemed a bit shorter than the previous 2.
"""
