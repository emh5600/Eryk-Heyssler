############################################################
# CMPSC 442: Homework 5
############################################################

student_name = "Eryk Heyssler"

############################################################
# Imports
############################################################

# Include your imports here, if any are used.
import string
import random
import math

############################################################
# Section 1: Markov Models
############################################################

def tokenize(text):
    l = []
    i = 0
    while i < (len(text)):
        token = ""
        if text[i] in (string.punctuation) and text[i] != '\n':
             l.append(text[i])
             i += 1
        elif text[i] != " " and text[i] != '\n':
            while i < len(text) and text[i] != " " and text[i] != '\n' and text[i] not in (string.punctuation + '\n'):
                token += text[i]
                i += 1
            l.append(token)
        else:
            i += 1
    return l

def ngrams(n, tokens):
    i = 0
    for i in range(n-1):
        tokens.insert(0,"<START>")
    tokens.append("<END>")

    i = n - 1
    ret = []
    while i < len(tokens):
        tup = []
        k = n - 1
        while k > 0:
            tup.append(tokens[i-k])
            k -= 1
        ret.append((tuple(tup),tokens[i]))
        i += 1
    return ret

class NgramModel(object):

    def __init__(self, n):
        self.order = n
        self.contextDic = {}        #{context : list({token : number of occurrences in this context},number of tokens total)}
                                    #P(token | context) = #occurrences of token in context / #total tokens in context

    def update(self, sentence):
        ngram = ngrams(self.order, tokenize(sentence))
        for context, token in ngram:
            if context in self.contextDic:
                if token in self.contextDic[context][0]:
                    self.contextDic[context][0][token] += 1     #update number of occurrences of token
                else:
                    self.contextDic[context][0][token] = 1      #set number of occurrences to 1
                self.contextDic[context][1] += 1                #update number of total tokens for that context
            else:
                item = [{token : 1},1]                          #add new context with a token set to 1
                self.contextDic[context] = item

    def prob(self, context, token):
        #count_1 = number of times a token appears in the context
        #count_2 = number of tokens in context (total)
        if context not in self.contextDic:
            return 0.0

        count_1 = self.contextDic[context][0].get(token)
        count_2 = self.contextDic[context][1]

        if count_1 == None or count_1 == 0.0 or count_2 == 0.0:
            return 0.0
        else:
            return count_1/count_2

    def random_token(self, context):
        if context not in self.contextDic:
            return None

        lexList = list(self.contextDic[context][0].items())
        lexList.sort()
        r = random.random()

        #a <= r < b
        a = 0
        b = 0

        for item in lexList:
            b += self.prob(context,item[0])
            if a <= r < b:
                return item[0]
            else:
                a = b

        return None

    def random_text(self, token_count):
        textList = []

        if self.order == 1:
            for i in range(token_count):
                token = self.random_token(())
                textList.append(token)
        else:
            #initialization
            startingContext = ("<START>",) * (self.order-1)
            context = startingContext
            token = ""

            for i in range(token_count):
                if i == 0 or token == "<END>":
                    context = startingContext
                token = self.random_token(context)
                textList.append(token)

                #update context
                context = context[1:] + (token,)

        return " ".join(textList)

    def perplexity(self, sentence):
        productSum = 0
        ngram = ngrams(self.order, tokenize(sentence))
        tokens = tokenize(sentence)
        m = len(tokens)

        for context,token in ngram:
            productSum += math.log(self.prob(context,token))

        return (1/math.exp(productSum)) ** (1/(m+1))

def create_ngram_model(n, path):
    file = open(path,'r')
    m = NgramModel(n)

    lines = file.readlines()
    for line in lines:
        m.update(line)

    return m

# --------------------   TEST CODE   -------------------- #
def testCorrectness():
    print("--------Q1--------")
    print(tokenize("    This is an example. ") ==
          ['This', 'is', 'an', 'example', '.'])
    print(tokenize("'Medium-rare,' she said.") ==
          ["'", 'Medium', '-', 'rare', ',', "'", 'she', 'said', '.'])

    print("--------Q2--------")
    print(ngrams(1, ["a", "b", "c"]) ==
          [((), 'a'), ((), 'b'), ((), 'c'),
           ((), '<END>')])
    print(ngrams(2, ["a", "b", "c"]) ==
          [(('<START>',), 'a'), (('a',), 'b'),
           (('b',), 'c'), (('c',), '<END>')])
    print(ngrams(3, ["a", "b", "c"]) ==
          [(('<START>', '<START>'), 'a'),
           (('<START>', 'a'), 'b'),
           (('a', 'b'), 'c'),
           (('b', 'c'), '<END>')])

    print("--------Q3--------")
    m1 = NgramModel(1)
    m1.update("a b c d")
    m1.update("a b a b")
    print(m1.prob((),"a"))
    print(m1.prob((),"c"))
    print(m1.prob((),"<END>"))

    m2 = NgramModel(2)
    m2.update("a b c d")
    m2.update("a b a b")
    print(m2.prob(("<START>",),"a"))
    print(m2.prob(("b",),"c"))
    print(m2.prob(("a",),"x"))

    print("--------Q4--------")
    random.seed(1)
    print([m1.random_token(()) for i in range(25)] ==
          ['<END>', 'c', 'b', 'a', 'a', 'a', 'b',
           'b', '<END>', '<END>', 'c', 'a', 'b',
           '<END>', 'a', 'b', 'a', 'd', 'd',
           '<END>', '<END>', 'b', 'd', 'a', 'a'])

    random.seed(2)
    print([m2.random_token(("<START>",)) for i in range(6)] ==
          ['a', 'a', 'a', 'a', 'a', 'a'])
    print([m2.random_token(("b",)) for i in range(6)] ==
          ['c', '<END>', 'a', 'a', 'a', '<END>'])

    print("--------Q5--------")
    random.seed(1)
    print(m1.random_text(13))
    random.seed(2)
    print(m2.random_text(15))

    random.seed(None)

    print("--------Q6--------")
    m = create_ngram_model(1, "frankenstein.txt")
    print(m.random_text(15))
    m = create_ngram_model(2, "frankenstein.txt")
    print(m.random_text(15))
    m = create_ngram_model(3, "frankenstein.txt")
    print(m.random_text(15))
    m = create_ngram_model(4, "frankenstein.txt")
    print(m.random_text(15))
    m = create_ngram_model(5, "frankenstein.txt")
    print(m.random_text(50))

    print("--------Q7--------")
    print(m1.perplexity("a b"))
    print(m2.perplexity("a b"))
# -------------------- END TEST CODE -------------------- #


############################################################
# Section 2: Feedback
############################################################

feedback_question_1 = """
I spent about 9 hours on this assignment
"""

feedback_question_2 = """
The first part about the UPDATE() & PROB() functions;
Once I got that done, the rest was easier.
Also, finding ways to speed up the code was an unexpected challenge
that took a decent amount of time.
"""

feedback_question_3 = """
I really like the assignment as a whole, it's easy to see how 
the concept of Markov Models can be extended to many other applications.
I wouldn't change anything about this assignment.
"""
