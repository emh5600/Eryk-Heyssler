#ifndef STRESS_SEND_RECV_H
#define STRESS_SEND_RECV_H

void run_stress_send_recv(size_t buffer_size, size_t num_threads, double load, useconds_t duration_usec);

#endif // STRESS_SEND_RECV_H
