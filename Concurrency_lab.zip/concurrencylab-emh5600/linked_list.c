#include "linked_list.h"
// Creates and returns a new list
list_t* list_create()
{
	list_t* list = malloc(sizeof(list_t));
	list->head = NULL;
	list->count = 0;

    return list;
}

// Destroys a list
void list_destroy(list_t* list)
{
    list_node_t* head = list_begin(list);
    list_node_t* temp;
    while(head)
    {
        temp=head;
        head=head->next;
        free(temp);
    }
}

// Returns beginning of the list
list_node_t* list_begin(list_t* list)
{
    return list->head;
}

// Returns next element in the list
list_node_t* list_next(list_node_t* node)
{
    return node->next;
}

// Returns data in the given list node
void* list_channel(list_node_t* node)
{
    return node->channel;
}
int list_dir(list_node_t* node)
{
    return node->dir;
}

// Returns the number of elements in the list
size_t list_count(list_t* list)
{
    return list->count;
}

// Inserts a new node in the list with the given data
void list_insert(list_t* list, void* channel, int dir)
{
    list_node_t* new_node = malloc(sizeof(list_node_t));
	if (list->head){
		list->head->prev = new_node;
	}

	new_node->prev = NULL;
	new_node->next = list->head;
	new_node->channel = channel;
    new_node->dir = dir;

	list->head = new_node;
	return;
	
}

// Removes a node from the list and frees the node resources
void list_remove(list_t* list, list_node_t* node)
{
	if (node == list->head){
		if (node->next){
			node->next->prev = NULL;
		}
		list->head = node->next;
		free(node);
	}
	else{
		if (node->prev){
			node->prev->next = node->next;
		}
		if (node->next){
			node->next->prev = node->prev;
		}
		free(node);
	}	
}


