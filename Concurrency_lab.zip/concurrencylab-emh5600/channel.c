#include "channel.h"
// Creates a new channel with the provided size and returns it to the caller
// A 0 size indicates an unbuffered channel, whereas a positive size indicates a buffered channel
channel_t* channel_create(size_t size)
{
    /* IMPLEMENT THIS */
    channel_t *channel = malloc(sizeof(channel_t));
    channel->buffer = buffer_create(size);
    
    //Initialize recursive mutex
    //pthread_mutex_init(&channel->mutex,NULL);
    pthread_mutexattr_init(&channel->attr);
    pthread_mutexattr_settype(&channel->attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&channel->mutex, &channel->attr);
    
    //Initialize semaphores
    sem_init(&channel->semNumMsg,0,0);
    sem_init(&channel->semCap,0,(unsigned int)size);
    
    //Initialize channel to be open;
    channel->closed = 0;
    
    //Extra variables for SELECT
    
    //Initialize semSelect to point to NULL
    channel->semSelect = NULL;
    //Initialize the select list to point to NULL
    channel->list = NULL;
    //Initialize select to be non-open
    channel->selectFlag = 0;
    channel->numChannelsSelect = 0;
    return channel;
}

// Writes data to the given channel
// This is a blocking call i.e., the function only returns on a successful completion of send
// In case the channel is full, the function waits till the channel has space to write the new data
// Returns SUCCESS for successfully writing data to the channel,
// CLOSED_ERROR if the channel is closed, and
// GEN_ERROR on encountering any other generic error of any sort
enum channel_status channel_send(channel_t *channel, void* data)
{
    int cap;
    sem_getvalue(&channel->semCap,&cap);
    sem_wait(&channel->semCap);
    
    /* Handle critical area */
    pthread_mutex_lock(&channel->mutex);
    
    //Check for closed channel
    if (channel->closed){
        pthread_mutex_unlock(&channel->mutex);
        sem_post(&channel->semNumMsg);
        sem_post(&channel->semCap);
        return CLOSED_ERROR;
    }
    
    //If select is called, push the channel onto the list
    if (channel->selectFlag){
        list_insert(channel->list,channel,RECV);
        sem_post(channel->semSelect);
    }
    
    //Add the message to the buffer
    buffer_add(channel->buffer,data);
    
    pthread_mutex_unlock(&channel->mutex);
    /* End critical area */
    
    sem_post(&channel->semNumMsg);
    return SUCCESS;
    
    
}

// Reads data from the given channel and stores it in the function’s input parameter, data (Note that it is a double pointer).
// This is a blocking call i.e., the function only returns on a successful completion of receive
// In case the channel is empty, the function waits till the channel has some data to read
// Returns SUCCESS for successful retrieval of data,
// CLOSED_ERROR if the channel is closed, and
// GEN_ERROR on encountering any other generic error of any sort
enum channel_status channel_receive(channel_t* channel, void** data)
{
    sem_wait(&channel->semNumMsg);
    
    /* Handle critical area */
    pthread_mutex_lock(&channel->mutex);
    
    //Check for closed channel
    if (channel->closed){
        pthread_mutex_unlock(&channel->mutex);
        sem_post(&channel->semNumMsg);
        sem_post(&channel->semCap);
        return CLOSED_ERROR;
    }
    
    //If select is called, push the channel onto the list
    if (channel->selectFlag){
        list_insert(channel->list,channel,SEND);
        sem_post(channel->semSelect);
    }
    
    //Remove the message from the buffer
    buffer_remove(channel->buffer,data);
    
    pthread_mutex_unlock(&channel->mutex);
    /* End critical area */
    
    sem_post(&channel->semCap);
    return SUCCESS;
}

// Writes data to the given channel
// This is a non-blocking call i.e., the function simply returns if the channel is full
// Returns SUCCESS for successfully writing data to the channel,
// CHANNEL_FULL if the channel is full and the data was not added to the buffer,
// CLOSED_ERROR if the channel is closed, and
// GEN_ERROR on encountering any other generic error of any sort
enum channel_status channel_non_blocking_send(channel_t* channel, void* data)
{
    //If the capacity semaphore is 0, return, otherwise decrement.
    int cap;
    sem_getvalue(&channel->semCap,&cap);
    if (!cap){
        return CHANNEL_FULL;
    }
    else{
        sem_wait(&channel->semCap);
    }
    
    /* Handle critical area */
    pthread_mutex_lock(&channel->mutex);
    
    //Check for closed channel
    if (channel->closed){
        pthread_mutex_unlock(&channel->mutex);
        sem_post(&channel->semNumMsg);
        sem_post(&channel->semCap);
        return CLOSED_ERROR;
    }
    
    //If select is called, push the channel onto the list
    if (channel->selectFlag){
        list_insert(channel->list,channel,RECV);
        sem_post(channel->semSelect);
    }
    
    //Add the message to the buffer
    buffer_add(channel->buffer,data);
    
    pthread_mutex_unlock(&channel->mutex);
    /* End critical area */
    
    sem_post(&channel->semNumMsg);
    return SUCCESS;
}

// Reads data from the given channel and stores it in the function’s input parameter data (Note that it is a double pointer)
// This is a non-blocking call i.e., the function simply returns if the channel is empty
// Returns SUCCESS for successful retrieval of data,
// CHANNEL_EMPTY if the channel is empty and nothing was stored in data,
// CLOSED_ERROR if the channel is closed, and
// GEN_ERROR on encountering any other generic error of any sort
enum channel_status channel_non_blocking_receive(channel_t* channel, void** data)
{
    //If the 'number of messages' semaphore is 0, return, otherwise decrement.
    int numMsg;
    sem_getvalue(&channel->semNumMsg,&numMsg);
    if(!numMsg){
        return CHANNEL_EMPTY;
    }
    else{
        sem_wait(&channel->semNumMsg);
    }
    
    /* Handle critical area */
    pthread_mutex_lock(&channel->mutex);
    
    //Check for closed channel
    if (channel->closed){
        pthread_mutex_unlock(&channel->mutex);
        sem_post(&channel->semNumMsg);
        sem_post(&channel->semCap);
        return CLOSED_ERROR;
    }
    
    //If select is called, push the channel onto the list
    if (channel->selectFlag){
        list_insert(channel->list,channel,SEND);
        sem_post(channel->semSelect);
    }
    
    //Remove the message from the buffer
    buffer_remove(channel->buffer,data);
    
    pthread_mutex_unlock(&channel->mutex);
    /* End critical area */
    
    sem_post(&channel->semCap);
    return SUCCESS;
}

// Closes the channel and informs all the blocking send/receive/select calls to return with CLOSED_ERROR
// Once the channel is closed, send/receive/select operations will cease to function and just return CLOSED_ERROR
// Returns SUCCESS if close is successful,
// CLOSED_ERROR if the channel is already closed, and
// GEN_ERROR in any other error case
enum channel_status channel_close(channel_t* channel)
{
    pthread_mutex_lock(&channel->mutex);
    if (channel->closed){
        pthread_mutex_unlock(&channel->mutex);
        return CLOSED_ERROR;
    }
    else{
        channel->closed = 1;
        //Signal sleeping threads
        sem_post(&channel->semCap);
        sem_post(&channel->semNumMsg);
        //Signal threads which are waiting in select
        if (channel->selectFlag)
            sem_post(channel->semSelect);
        pthread_mutex_unlock(&channel->mutex);
        return SUCCESS;
    }
}

// Frees all the memory allocated to the channel
// The caller is responsible for calling channel_close and waiting for all threads to finish their tasks before calling channel_destroy
// Returns SUCCESS if destroy is successful,
// DESTROY_ERROR if channel_destroy is called on an open channel, and
// GEN_ERROR in any other error case
enum channel_status channel_destroy(channel_t* channel)
{
    
    if (!channel->closed)
        return DESTROY_ERROR;
    
    pthread_mutex_destroy(&channel->mutex);
    sem_destroy(&channel->semNumMsg);
    sem_destroy(&channel->semCap);
    
    //Destroy local vars of select if they haven't already been taken care of
    int numPostedSelect = 0;
    if (channel->selectFlag){
        sem_getvalue(channel->semSelect,&numPostedSelect);
        if (channel->numChannelsSelect && (numPostedSelect == channel->numChannelsSelect - 1)){
            channel_select_clean(&channel->list,&channel->semSelect);
        }
    }
    buffer_free(channel->buffer);
    free(channel);
    return SUCCESS;
}

// Takes an array of channels, channel_list, of type select_t and the array length, channel_count, as inputs
// This API iterates over the provided list and finds the set of possible channels which can be used to invoke the required operation (send or receive) specified in select_t
// If multiple options are available, it selects the first option and performs its corresponding action
// If no channel is available, the call is blocked and waits till it finds a channel which supports its required operation
// Once an operation has been successfully performed, select should set selected_index to the index of the channel that performed the operation and then return SUCCESS
// In the event that a channel is closed or encounters any error, the error should be propagated and returned through select
// Additionally, selected_index is set to the index of the channel that generated the error
enum channel_status channel_select(select_t* channel_list, size_t channel_count, size_t* selected_index)
{
    //Initialize the linked list
    list_t* list = list_create();
    //Store semaphore as a local variable
    sem_t* semSelect = malloc(sizeof(sem_t));
    //Semaphore value will store number of potential channels that can carry out their actions
    sem_init(semSelect,0,(unsigned int)channel_count);
    //Iterate through the channels to find one that can carry out its action
    for (size_t i = 0; i < (int)channel_count; i++){
        
        pthread_mutex_lock(&channel_list[i].channel->mutex);
        channel_list[i].channel->numChannelsSelect = (int)channel_count;
        if (channel_list[i].channel->closed){
            //Clean in case we encounter a closed channel
            channel_select_clean(&list,&semSelect);
            pthread_mutex_unlock(&channel_list[i].channel->mutex);
            return CLOSED_ERROR;
        }
        //Set the channel's variables to locals only if a previous select has NOT been called on this channel.
        if (!channel_list[i].channel->selectFlag){
            channel_list[i].channel->semSelect = semSelect; //Set the channels' semaphore pointer to local semaphore
            channel_list[i].channel->list = list; //Set the channels' list pointer to local list
            channel_list[i].channel->selectFlag = 1;
        }
        
        //if RECV
        if (channel_list[i].dir){
            int status = channel_non_blocking_receive(channel_list[i].channel,&channel_list[i].data);
            if (status == CHANNEL_EMPTY){
                sem_wait(semSelect); //Decrement the semaphore
                
                //Channel closes in the middle of select
                if (channel_list[i].channel->closed){
                    channel_select_clean(&list,&semSelect); //Clean locals
                    pthread_mutex_unlock(&channel_list[i].channel->mutex);
                    return CLOSED_ERROR;
                }
                
            }
            else{
                *selected_index = i;
                channel_select_clean(&list,&semSelect); //Clean locals
                pthread_mutex_unlock(&channel_list[i].channel->mutex);
                return status;
            }
        }
        //if SEND
        else{
            int status = channel_non_blocking_send(channel_list[i].channel,channel_list[i].data);
            if (status == CHANNEL_FULL){
                sem_wait(semSelect); //Decrement the semaphore
                
                //Channel closes in the middle of select
                if (channel_list[i].channel->closed){
                    channel_select_clean(&list,&semSelect); //Clean locals
                    pthread_mutex_unlock(&channel_list[i].channel->mutex);
                    return CLOSED_ERROR;
                }
                
                
            }
            else{
                *selected_index = i;
                channel_select_clean(&list,&semSelect); //Clean locals
                pthread_mutex_unlock(&channel_list[i].channel->mutex);
                return status;
            }
        }
        
        pthread_mutex_unlock(&channel_list[i].channel->mutex);
    }
    
    
    //Have not found a channel that was able to do its action, so we wait (block) until a post from send or receive
    sem_wait(semSelect);
    //Once we post, we should have an item in the list -- we take the item, and compare it to our channel_list.
    if (list_begin(list)){
        channel_t* currChannel = (channel_t*)list_channel(list_begin(list));
        int currDir = list_dir(list_begin(list));
        
        for (size_t i = 0; i < (int)channel_count; i++){
            pthread_mutex_lock(&channel_list[i].channel->mutex);
            channel_list[i].channel->selectFlag = 0;
            
            //Run the corresponding action
            if (channel_list[i].channel == currChannel && channel_list[i].dir == currDir){
                if (currDir){ // RECV
                    if (channel_non_blocking_receive(channel_list[i].channel,&channel_list[i].data) == SUCCESS)
                        *selected_index = i;
                }
                else{         //SEND
                    if (channel_non_blocking_send(channel_list[i].channel,channel_list[i].data) == SUCCESS)
                        *selected_index = i;
                }
            }
            pthread_mutex_unlock(&channel_list[i].channel->mutex);
        }
    }
    else{
        return CLOSED_ERROR;
    }
    //Clean locals
    channel_select_clean(&list,&semSelect);
    return SUCCESS;
}

//Helper function to clean up local variables of select function
void channel_select_clean(list_t** list, sem_t** semSelect){
    if (*list){
        list_destroy(*list);
        free(*list);
    }
    if (*semSelect){
        sem_destroy(*semSelect);
        free(*semSelect);
    }
    return;
}
