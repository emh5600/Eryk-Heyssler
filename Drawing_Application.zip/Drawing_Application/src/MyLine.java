import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;

public class MyLine extends MyShape{

    
    public MyLine(){
        super();
    }
    
    public MyLine(int x1, int x2, int y1, int y2, GradientPaint gradientPaint,BasicStroke basicStroke){
        super(x1,x2,y1,y2,gradientPaint,basicStroke);
    }
    
    @Override
    public void draw(Graphics2D g){
        g.setPaint(getGradientPaint());
        g.setStroke(getBasicStroke());
        g.drawLine(getX1(), getY1(), getX2(), getY2());
    }
}

