import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;

public abstract class MyShape {
    private int x1;
    private int x2;
    private int y1;
    private int y2;
    private GradientPaint gradientPaint;
    private BasicStroke basicStroke;
    
    public MyShape(){
        this.x1 = 0;
        this.x2 = 0;
        this.y1 = 0;
        this.y2 = 0;
        this.gradientPaint = new GradientPaint(0,0,Color.BLACK,50,50,Color.BLACK,true);
        this.basicStroke = new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND);
    }
    
    public MyShape(int x1, int x2, int y1, int y2, GradientPaint gradientPaint,BasicStroke basicStroke){
        setX1(x1);
        setX2(x2);
        setY1(y1);
        setY2(y2);
        this.gradientPaint = gradientPaint;
        this.basicStroke = basicStroke;
    }
    
    public void setX1(int x1){
        this.x1 = x1;
    }
    
    public void setX2(int x2){
        this.x2 = x2;
    }
    
    public void setY1(int y1){
        this.y1 = y1;
    }
    
    public void setY2(int y2){
        this.y2 = y2;
    }

    public int getX1(){
        return x1;
    }
    
    public int getX2(){
        return x2;
    }
    
    public int getY1(){
        return y1;
    }
    
    public int getY2(){
        return y2;
    }

    public GradientPaint getGradientPaint(){
        return gradientPaint;
    }
    
    public BasicStroke getBasicStroke(){
        return basicStroke;
    }
    
    public abstract void draw(Graphics2D g);
}
