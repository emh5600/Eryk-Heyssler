import javax.swing.JFrame;
public class main {
    public static void main(String[] args){
        DrawFrame drawApp = new DrawFrame();
        drawApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        drawApp.setSize(1000,700);
        drawApp.setVisible(true);
    }
}
