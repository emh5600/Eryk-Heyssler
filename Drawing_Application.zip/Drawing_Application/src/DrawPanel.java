import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;

public class DrawPanel extends JPanel{
    private final MyShape[] shapes;
    private int shapeCount;
    private int shapeType;
    MyShape currentShape;
    GradientPaint currentGradientPaint;
    boolean filledShape;
    JLabel statusLabel;
    BasicStroke basicStroke;
    
    public DrawPanel(JLabel statusLabel){
        this.statusLabel = statusLabel;
        this.shapes = new MyShape[100];
        this.shapeCount = 0;
        this.shapeType = 0;
        this.currentShape = null;
        this.currentGradientPaint = new GradientPaint(0,0,Color.BLACK,50,50,Color.BLACK,true);
        this.basicStroke = new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND);
        
        setBackground(Color.WHITE);
        this.statusLabel = statusLabel;
        
        MouseHandler mouseHandler = new MouseHandler();
        addMouseMotionListener(mouseHandler);
        addMouseListener(mouseHandler);
    }
    
    
    //MouseHandler
    private class MouseHandler extends MouseAdapter implements MouseMotionListener{
        @Override
        public void mousePressed(MouseEvent event){
            switch (getShapeType()) {
                case 0:
                    currentShape = new MyLine( event.getX(), event.getY(), event.getX(), event.getY(), currentGradientPaint,basicStroke);
                    break;
                case 1:
                    currentShape = new MyRectangle(event.getX(), event.getY(), event.getX(), event.getY(), currentGradientPaint, filledShape, basicStroke);
                    break;
                case 2:
                    currentShape = new MyOval(event.getX(), event.getY(), event.getX(), event.getY(), currentGradientPaint, filledShape, basicStroke);
                    break;
                default:
                    break;
            }
            
            currentShape.setX1(event.getX());
            currentShape.setY1(event.getY());
        }
        @Override
        public void mouseReleased(MouseEvent event){
            currentShape.setX2(event.getX());
            currentShape.setY2(event.getY());
            
            shapes[shapeCount] = currentShape;
            shapeCount+=1;
            currentShape = null;
            repaint();
        }
        
        @Override
        public void mouseMoved(MouseEvent event){
            statusLabel.setText(String.format("(%d,%d)",event.getX(),event.getY()));
        }
        
        @Override
        public void mouseDragged(MouseEvent event){
            currentShape.setX2(event.getX());
            currentShape.setY2(event.getY());
            repaint();
            statusLabel.setText(String.format("(%d,%d)",event.getX(),event.getY()));
        }
       
    }//end of MouseHandler
    
    
    public void setShapeType(int shapeType){
        this.shapeType = shapeType;
    }
    
    public int getShapeType(){
        return shapeType;
    }
    
    public void setCurrentGradientPaint(GradientPaint currentGradientPaint){
        this.currentGradientPaint = currentGradientPaint;
    }
    
    public void setFilledShape(boolean filledShape){
        this.filledShape = filledShape;
    }
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
      
        for (int i = 0; i<shapeCount;i++){
            if (shapes[i] != null)
                shapes[i].draw(g2d);
        }
        
        if (currentShape != null)
            currentShape.draw(g2d);
    }
    
    public void clearLastShape(){
        if (shapeCount > 0){
            shapeCount -= 1;
        }
        repaint();
    }
    
    public void clearDrawing(){
        shapeCount = 0;
        repaint();
    }
    
    public void setBasicStroke(BasicStroke basicStroke){
        this.basicStroke = basicStroke;
    }
}
