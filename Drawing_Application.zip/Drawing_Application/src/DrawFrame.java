import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JComboBox;
import java.awt.FlowLayout;
import java.awt.BasicStroke;
import java.awt.GradientPaint;
import javax.swing.JColorChooser;
import javax.swing.BoxLayout;

public class DrawFrame extends JFrame {
    private final JButton undo;
    private final JButton clear;
    private final JComboBox<String> shapes;
    private final JCheckBox filled;
    private final JLabel statusLabel;
    private final DrawPanel panel;
  
    
    private final JLabel textLabel1;
    private final JLabel textLabel2;
    
    private final JCheckBox gradient;
    
    private Color color1 = Color.BLACK;
    private Color color2 = Color.BLACK;
    
    private final JButton color1Button;
    private final JButton color2Button;
    
    private final JTextField lineWidthTextField;
    private final JTextField dashLengthTextField;
    
    private int strokeWidth = 5;
    private float[] strokeDashes = {10};
    private final JCheckBox dashed;
    
    private final JPanel doublePanel;
    private final JPanel componentJPanel;
    private final JPanel componentJPanel2;
   
    private final String[] shapeNames = {"Line","Rectangle","Oval"};
    
    public DrawFrame(){
        super("Drawing Application");
        
        setLayout(new BorderLayout());
        
        undo = new JButton("Undo");
        undo.setVisible(true);
        
        clear = new JButton("Clear");
        clear.setVisible(true);
        
        shapes = new JComboBox<>(shapeNames);
        shapes.setVisible(true);
        
        filled = new JCheckBox("Filled");
        filled.setVisible(true);
        
        //GRADIENT BOX
        gradient = new JCheckBox("Use Gradient");
        gradient.setVisible(true);
        
        //COLOR BUTTONS
        color1Button = new JButton("1st Color...");
        color1Button.setVisible(true);
        color2Button = new JButton("2nd Color...");
        color2Button.setVisible(true);
        
        //TEXT FIELDS
        lineWidthTextField = new JTextField(2);
        add(lineWidthTextField);
        dashLengthTextField = new JTextField(2);
        add(dashLengthTextField);
        
        textLabel1 = new JLabel("Line Width:");
        add(textLabel1);
        textLabel2 = new JLabel("Dash Length:");
        add(textLabel2);
        
        //DASHED BOX
        dashed = new JCheckBox("Dashed");
        dashed.setVisible(true);
        
        //int strokeWidth = 5;                               //initial stroke
        //float[] strokeDashes = {10};
        
        //BORDERLAYOUT COMPONENTS
        statusLabel = new JLabel();
        statusLabel.setVisible(true);
        add(statusLabel,BorderLayout.SOUTH);
        
        panel = new DrawPanel(statusLabel);
        panel.setVisible(true);
        add(panel,BorderLayout.CENTER);
        
        //COMPONENT JPANEL
        componentJPanel = new JPanel();
        componentJPanel.setLayout(new FlowLayout());
        
        componentJPanel2 = new JPanel();
        componentJPanel2.setLayout(new FlowLayout());
        
        doublePanel = new JPanel();
        doublePanel.setLayout(new BoxLayout(doublePanel,BoxLayout.Y_AXIS));
        
        componentJPanel.add(undo);
        componentJPanel.add(clear);
        componentJPanel.add(shapes);
        componentJPanel.add(filled);
        componentJPanel2.add(gradient);
        componentJPanel2.add(color1Button);
        componentJPanel2.add(color2Button);
        componentJPanel2.add(textLabel1);
        componentJPanel2.add(lineWidthTextField);
        componentJPanel2.add(textLabel2);
        componentJPanel2.add(dashLengthTextField);
        componentJPanel2.add(dashed);
        
        doublePanel.add(componentJPanel);
        doublePanel.add(componentJPanel2);
        add(doublePanel,BorderLayout.NORTH);
        
        //HANDLERS 
        ButtonHandler buttonHandler = new ButtonHandler();
        undo.addActionListener(buttonHandler);
        clear.addActionListener(buttonHandler);
        color1Button.addActionListener(buttonHandler);
        color2Button.addActionListener(buttonHandler);
        
        ItemHandler itemHandler = new ItemHandler();
        filled.addItemListener(itemHandler);
        shapes.addItemListener(itemHandler);
        gradient.addItemListener(itemHandler);
        dashed.addItemListener(itemHandler);
        
        TextFieldHandler textFieldHandler = new TextFieldHandler();
        lineWidthTextField.addActionListener(textFieldHandler);
        dashLengthTextField.addActionListener(textFieldHandler);
    }///end constructor
    

    private class ButtonHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent event)
        {
            //UNDO BUTTON
            if (event.getActionCommand().equals("Undo")){
                panel.clearLastShape();
            }
            //CLEAR BUTTON
            else if (event.getActionCommand().equals("Clear")){
                panel.clearDrawing();
            }
            else if (event.getActionCommand().equals("1st Color...")){
                color1 = JColorChooser.showDialog(
                    DrawFrame.this,"Choose the 1st Color", color1);
                if (gradient.isSelected()){
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color2,true));
                }
                else
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color1,true));
                
            }
            else if (event.getActionCommand().equals("2nd Color...")){
                color2 = JColorChooser.showDialog(
                    DrawFrame.this,"Choose the 2nd Color", color2);
                if (gradient.isSelected()){
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color2,true));
                }
                else
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color1,true));
            } 
        } 
    }//end ButtonHandler 
    
    private class ItemHandler implements ItemListener
    {
        @Override
        public void itemStateChanged(ItemEvent event)
        {
            // CHECKBOXES
            if (event.getSource() == filled)
            {
                if (filled.isSelected()){
                    panel.setFilledShape(true);
                }
                else
                    panel.setFilledShape(false);
            }
            
            else if (event.getSource() == gradient){
                if (gradient.isSelected()){
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color2,true));
                }
                else
                    panel.setCurrentGradientPaint(new GradientPaint(0,0,color1,50,50,color1,true));
            }
            
            else if (event.getSource() == dashed){
                if (dashed.isSelected()){
                    panel.setBasicStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,10,strokeDashes,0));
                }
                else
                    panel.setBasicStroke(new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            }
            
            // COMBO BOXES
            if (event.getStateChange() == ItemEvent.SELECTED)
            {
                //SHAPE COMBO BOX
                if ( event.getSource() == shapes)
                {
                    panel.setShapeType(shapes.getSelectedIndex());
                }
            }
            
        }
    }//end item handler
    
    private class TextFieldHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            int number = Integer.parseInt(event.getActionCommand());
            //if user pressed Enter in JTextField
            if (event.getSource() == lineWidthTextField){
                strokeWidth = number;
                
                if (dashed.isSelected()){
                    panel.setBasicStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,10,strokeDashes,0));
                }
                else
                    panel.setBasicStroke(new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            }
            else if (event.getSource() == dashLengthTextField){
                strokeDashes[0] = number;
                
                if (dashed.isSelected()){
                    panel.setBasicStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,10,strokeDashes,0));
                }
                else
                    panel.setBasicStroke(new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            }
        }
    }//end TextFieldHandler
    
    
}
