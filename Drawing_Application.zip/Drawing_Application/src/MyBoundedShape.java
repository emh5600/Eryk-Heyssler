import java.awt.BasicStroke;
import java.awt.GradientPaint;

public abstract class MyBoundedShape extends MyShape{
    private boolean filled; 
    
    public MyBoundedShape(){
        super();
        this.filled = false;
    }
    
    public MyBoundedShape(int x1, int x2, int y1, int y2, GradientPaint gradientPaint, boolean filled,BasicStroke basicStroke){
        super(x1,x2,y1,y2,gradientPaint,basicStroke);
        setFilled(filled);
    }
    
    private void setFilled(boolean filled){
        this.filled = filled;
    }
    
    public boolean getFilled(){
        return filled;
    }
    public int getUpperLeftX(){
        if (getX1() <= getX2())
            return getX1();
        else
            return getX2();
    }
    
    public int getUpperLeftY(){
        if (getY1() <= getY2())
            return getY1();
        else
            return getY2();
    }
    
    public int getWidth(){
        return Math.abs(getX2()-getX1());
    }
    
    public int getHeight(){
        return Math.abs(getY2()-getY1());
    }
    
}
