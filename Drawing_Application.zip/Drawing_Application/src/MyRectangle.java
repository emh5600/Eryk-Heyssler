import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;

public class MyRectangle extends MyBoundedShape{

    public MyRectangle(){
        super();
    }
    
    public MyRectangle(int x1, int x2, int y1, int y2, GradientPaint gradientPaint, boolean filled, BasicStroke basicStroke){
        super(x1,x2,y1,y2,gradientPaint,filled,basicStroke);
    }
    
    @Override
    public void draw(Graphics2D g){
        g.setPaint(getGradientPaint());
        g.setStroke(getBasicStroke());
        if (getFilled() == false)
            g.drawRect(getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight());
        else
            g.fillRect(getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight());
    }
}
