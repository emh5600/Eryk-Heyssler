#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

#include <stdio.h>
#include <string.h>

void swap(int *x,int *y);

int main(){
	int x = 5;
	int y = 4;

	int *ptrx = &x;
	int *ptry = &y;

	swap(ptrx,ptry);

	cout<<"x is: "<<x<<endl;
	cout<<"y is: "<<y<<endl;
}

void swap(int *x, int *y){
	int temp = *x;
	*x = *y;
	*y = temp;
}
