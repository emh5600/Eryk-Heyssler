javac p2.java
java p2 < test.txt
