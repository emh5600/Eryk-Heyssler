#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;
/*import for strtok */
#include <string.h>
#include <stdio.h>
class Node{
	public:
		Node *left_;
        Node *right_;
        Node *parent_ = NULL;
        char *val_;

		Node(char *c){
        	val_ = c;
			left_ = NULL;
			right_ = NULL;
		}

		~Node(){
			delete left_;
			delete right_;
			delete val_;
		}
};

class Tree{
    public:
        Node *root_;
        virtual Node* build_expression_tree(char *args[100],int size) = 0;
        virtual double evaluate_expression_tree(Node *node) = 0;
};

class Expressiontree:Tree{
	public:
		Expressiontree(){
			root_ = NULL;
		}

		Node* build_expression_tree(char *args[100],int size){
			if (is_infix(args,size))
					cout<<"The input expression is in infix!"<<endl;
			/* create a root node */			
			Node *root = new Node(args[size]);
			size--;
			/* construct subtrees */
			Node *currentnode = root;
			while (size >= 0){
				Node *node = new Node(args[size]);	
				/* if children are empty */
				if (!(currentnode->right_) && is_op(currentnode->val_)){
						currentnode->right_ = node;
            			currentnode->right_->parent_ = currentnode;
            			currentnode = node;
					}
				/* else, search for a parent with eligible child */
				else{
					while ((currentnode->parent_) || (currentnode == root)){
						if (!(currentnode->left_) && is_op(currentnode->val_)){	
							currentnode->left_ = node;
            				currentnode->left_->parent_ = currentnode;
            				currentnode = node;
							break;
						}
						else{
							if (currentnode == root){
								cout<<"FATAL ERROR"<<endl;	
								exit(EXIT_FAILURE);
							}
							else{
								currentnode = currentnode->parent_;
							}
						}
					}
				}
				size--;
			}
			return root_ = root;
		}
		
		double evaluate_expression_tree(Node* currentnode){
			if (atof(currentnode->val_))
				return atof(currentnode->val_);
			
			Node *right = currentnode->right_;
			Node *left = currentnode->left_;

			if (is_op(currentnode->val_)){
				switch(*currentnode->val_){
					case '+' : return (evaluate_expression_tree(left) +
						   	   evaluate_expression_tree(right));
						   	  break;
					case '-' : return (evaluate_expression_tree(left) -
							   evaluate_expression_tree(right));
							   break;
					case '*' : return (evaluate_expression_tree(left) *
							   evaluate_expression_tree(right));
							   break;
					case '/' : return (evaluate_expression_tree(left) /
							   evaluate_expression_tree(right));
							   break;
				}	
			}
		}

		string inorder(Node* currentnode){
			if (is_op(currentnode->val_)){
				return "(" + inorder(currentnode->left_) + currentnode->val_
						+ inorder(currentnode->right_) + ")";
			}
			else
				return currentnode->val_;
		}

		~Expressiontree(){
			root_ = NULL;
		}

	private:
		bool is_op(char *operand){
			char ops[4] = {'+','-','/','*'};
			bool val = false;
			for (int i = 0; i < 4; i++){
				if (ops[i] == *operand){
					val = true;
				}
			}
			return val;
		}

		bool is_infix(char *args[100], int size){
			if ((size != 0) && (is_op(args[size])))
					return false;
			else
					return true;
		}

};


int main() {
	string input;
	Expressiontree *exprtree = new Expressiontree();

	while(cin)
	{
		getline(cin, input);
		cout<<"The input is: "<<input<<endl;

		if (input.empty()){
			cout<<"Empty input. Exiting."<<endl;
			break;
		}
		
		/* tokenize the input */
		char *p = strtok(&input[0], " ");
		char *exprtokens[100];
		int i = 0;
		while (p) {
			exprtokens[i] = p;
			i++;
			p = strtok(NULL, " ");
		}
		/* build expression tree */
		Node *root = exprtree->build_expression_tree(exprtokens,i-1);
		/* print inorder */
		string inorder = exprtree->inorder(root);
		cout<<"The inorder traversal is: "<<inorder<<endl;
		/* evaluate expression tree */
		cout<<"The output of the expression is: "<<
				exprtree->evaluate_expression_tree(root)<<endl;
	}
	return 0;
}

