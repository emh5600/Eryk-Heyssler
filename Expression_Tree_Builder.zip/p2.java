import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class p2 {
    public static final int MAX_EXPR_LENGTH = 100;

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String input;
		while((input = reader.readLine()) != null ){
       	 	ExpressionTree tree = new ExpressionTree(input);

			if (tree.is_postfix(input)){
				System.out.println("The input is: " + input);
        		System.out.println("The inorder traversal is: " + tree.inOrder());
			}
			else
				System.out.println("The inorder traversal is: " + input);
        	System.out.println("The output of the expression is: " + tree.evaluate_expression_tree());

    	}
	}
}

interface TreeAble {
    ExprTreeNode build_expression_tree(String postfixString);

    double evaluate_expression_tree();
}

class ExpressionTree implements TreeAble {
    private ExprTreeNode root;

    public ExpressionTree(String postfixString) {
        this.root = build_expression_tree(postfixString);
    }

    public ExprTreeNode build_expression_tree(String postfixExpression) {
		String[] postfix = postfixExpression.split(" ", p2.MAX_EXPR_LENGTH);

		/*if the expression is not in postfix (infix), translate it */
		if (!is_postfix(postfixExpression)){
			postfix = infix2postfix(postfix);
			String delimiter = " "; 
			System.out.println("The input is: " + String.join(delimiter, postfix));
		}
		
		

        ExprTreeNodeStack stack = new ExprTreeNodeStack();
        ExprTreeNode left, right;
        for (String str : postfix) {
            if (str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/")) {
                right = stack.pop();
                left = stack.pop();
                stack.push(new OperatorNode(left, right, str));
            } else {
                stack.push(new ValueNode(str));
            }
        }
        return stack.pop();
    }

    public double evaluate_expression_tree() {
        return this.root.evaluate();
    }

	public boolean is_postfix(String expr){
		char ch = expr.charAt(expr.length()-1);

		if (ch == '+' || ch == '-' || ch == '*' || ch == '/'){
			return true;
		}
		else
			return false;

	}

	/* translate an infix expression to postfix */
	private String[] infix2postfix(String[] expr){
		int i = find_lowr(expr);
		int k = expr.length-1;
		if (i == -1){
			return expr;
		}
		else{
			String[] left = substr(expr,0,i-1);
			String[] right = substr(expr,i+1,k);
			String[] op = {expr[i]};
			/* this is essentially: return infix2postfix(left) + infix2postfix(right) + op */
			return catstr(catstr(infix2postfix(left),infix2postfix(right)),op);	
		}
	}
	
	/* find index of rightmost operator with lowest precedence */
	private int find_lowr(String[] expr){
		int i = expr.length - 1;
		int j = -1;
		String str;
		while (i >= 0){
			str = expr[i];
			if (str.equals("+") || str.equals("-"))
				return i;
			else if (str.equals("*") || str.equals("/")){
				if (j == -1)
					j = i;
			}
			i--;
		}
		return j;
	}

	/* find substring given start index a, end index z, INCLUDING a&z */
	private String[] substr(String[] arr,int a, int z){
		String[] sub = new String[z-a+1];					
		int i = 0;
		while (a <= z){
			sub[i] = arr[a];
			a++;
			i++;
		}
		return sub;
	}

	/* Concatenate 2 String[]'s */
	private String[] catstr(String[] str1, String[] str2){
		int n = str1.length + str2.length;
		String[] cat = new String[n];
		int i = 0;
		while (i < str1.length){
			cat[i] = str1[i];
			i++;
		}
		int j = 0;
		for (int k = i; k < n; k++){
			cat[k] = str2[j];
			j++;
		}
		return cat;
	}

    public String inOrder() {
        return this.root.inOrder();
    }
}

abstract class ExprTreeNode {
    public abstract double evaluate();

    public abstract String inOrder();
}

class ValueNode extends ExprTreeNode {
    private String value;

    public ValueNode(String value) {
        this.value = value;
    }

    public double evaluate() {
        return Double.parseDouble(this.value);
    }

    public String inOrder() {
        return this.value;
    }
}

class OperatorNode extends ExprTreeNode {
    private ExprTreeNode left;
    private ExprTreeNode right;
    private String operator;

    public OperatorNode(ExprTreeNode left, ExprTreeNode right, String operator) {
        this.left = left;
        this.right = right;
        this.operator = operator;
    }

    public double evaluate() {
        if (operator.equals("+")) {
            return this.left.evaluate() + this.right.evaluate();
        } else if (operator.equals("-")) {
            return this.left.evaluate() - this.right.evaluate();
        } else if (operator.equals("*")) {
            return this.left.evaluate() * this.right.evaluate();
        } else if (operator.equals("/")) {
            return this.left.evaluate() / this.right.evaluate();
        } else {
            // undefined operator
            return 0;
        }
    }

    public String inOrder() {
        return this.left.inOrder() + " " + this.operator + " " + this.right.inOrder();
    }
}

class ExprTreeNodeStack {
    private ExprTreeNode[] stack;
    private int pos;

    public ExprTreeNodeStack() {
        stack = new ExprTreeNode[p2.MAX_EXPR_LENGTH];
        pos = 0;
    }

    public void push(ExprTreeNode node) {
        stack[pos] = node;
        pos++;
        if (pos > 99) {
            // out of bounds
        }
    }

    public ExprTreeNode pop() {
        pos--;
        return stack[pos];
    }
}
