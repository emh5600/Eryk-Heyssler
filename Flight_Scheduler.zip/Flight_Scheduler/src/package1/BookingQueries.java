package package1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class BookingQueries {
    private static final String URL = "jdbc:derby://localhost:1527/FlightSchedulerDBErykemh5600";
    private static final String ACCOUNT = "java";
    private Connection connection;
    
    
    private PreparedStatement insertNewCustomer;
    private PreparedStatement selectAllCustomers;
    private PreparedStatement selectAllFlights;
    private PreparedStatement insertNewBooking;
    private PreparedStatement selectBookingCustomers;
    private PreparedStatement selectWaitlistCustomers;
    
    private PreparedStatement deleteFromWaitlist;
    
    private PreparedStatement selectCustomersFlightDayStatus;
    private PreparedStatement selectCustomersWaitlistStatus;
    private PreparedStatement selectFlightWaitlistStatus;
    
    private PreparedStatement seatCheck;
    private PreparedStatement insertNewWaitlist;
    
    //PART 2
    private PreparedStatement insertNewFlight;
    private PreparedStatement insertNewDate;
    private PreparedStatement selectAllDates;
    private PreparedStatement selectCustomersStatusBookings;
    private PreparedStatement selectCustomersStatusWaitlist;
    private PreparedStatement removeCustomerDay;
    private PreparedStatement searchFlightsBookings;
    private PreparedStatement searchFlightsWaitlist;
    private PreparedStatement removeCustomerDay2;
    private PreparedStatement bump;
    private PreparedStatement selectFlightCustomers;
    private PreparedStatement selectOneDate;
    private PreparedStatement removeFlight;
    private PreparedStatement updateBooking;
    private PreparedStatement searchWaitlistD;
    
    //CONSTRUCTOR
    public BookingQueries(){
        try{
            connection = DriverManager.getConnection(URL,ACCOUNT,ACCOUNT);
            
            insertNewCustomer = connection.prepareStatement("INSERT INTO Customer" +
                    "(Name)" + "VALUES(?)");
            
            selectAllCustomers = connection.prepareStatement("SELECT * FROM Customer");
            selectAllFlights = connection.prepareStatement("Select * FROM Flight");
            selectAllDates = connection.prepareStatement("SELECT * From Day");
            
            insertNewBooking = connection.prepareStatement("INSERT INTO Bookings" +
                    "(Customer,Flight,Day)" + "VALUES(?,?,?)");
            
            selectBookingCustomers = connection.prepareStatement("SELECT Customer FROM Bookings");
            selectWaitlistCustomers = connection.prepareStatement("SELECT Customer FROM Waitlist");
            
            insertNewWaitlist = connection.prepareStatement("INSERT INTO Waitlist" + 
                    "(Customer,Flight,Day)" + "VALUES(?,?,?)");
            
            insertNewFlight = connection.prepareStatement("INSERT INTO Flight" +
                    "(Name,Seats)" + "VALUES(?,?)");
            
            insertNewDate = connection.prepareStatement("INSERT INTO Day"+
                    "(Date)" + "VALUES(?)");
            
        }
        catch (SQLException sqlException){
            sqlException.printStackTrace();
            System.exit(1);
        }
    }//
    
    //ADD DATE TO DATABASE
    public void addDate(String date){
        try{
            insertNewDate.setString(1, date);
            insertNewDate.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //ADD FLIGHT TO DATABASE
    public void addFlight(String name, int seats){
        try{
            insertNewFlight.setString(1, name);
            insertNewFlight.setInt(2, seats);
            insertNewFlight.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //REMOVE FLIGHT FROM FLIGHT
    public void removeFlight(String name){
        try{
            /*/from bookings
            String string = "DELETE FROM Bookings WHERE Flight = ;" + name +"'";
            removeFlight = connection.prepareStatement(string);
            removeFlight.executeUpdate();*/
            //from flight
            String string = "DELETE FROM Flight WHERE Name = '" + name +"'";
            removeFlight = connection.prepareStatement(string);
            removeFlight.executeUpdate();
            /*/from waitlist
            string = "DELETE FROM Waitlist WHERE Flight = ;" + name +"'";
            removeFlight = connection.prepareStatement(string);
            removeFlight.executeUpdate();*/
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //REMOVE FLIGHT FROM BOOKINGS,WAITLIST, RETURNS CANCELLATIONS ON WAITLIST
    public List<String> removeFlightBW(String name){
        
        List<String> strings = null;
        ResultSet resultSet = null;
        
        try{
            //from bookings
            String string = "DELETE FROM Bookings WHERE Flight = '" + name +"'";
            removeFlight = connection.prepareStatement(string);
            removeFlight.executeUpdate();
            //from waitlist
            String search = "SELECT Customer,Day From Waitlist WHERE Flight ='"+name+"'";
            searchWaitlistD = connection.prepareStatement(search);
            
            resultSet = searchWaitlistD.executeQuery();
            strings = new ArrayList<String>();
            
            while (resultSet.next()){
                strings.add(new String("Customer "+resultSet.getString("Customer") +" cancelled from waitlist: Flight "+name+", Day "
                        +resultSet.getString("Day")+".\n"));
            }
            
            string = "DELETE FROM Waitlist WHERE Flight = '" + name +"'";
            removeFlight = connection.prepareStatement(string);
            removeFlight.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
        
        return strings;
    }//
    
    //ADD CUSTOMER TO DATABASE
    public void addCustomer(String name){
        try{
            insertNewCustomer.setString(1, name);
            insertNewCustomer.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //REMOVE CUSTOMER's BOOKING BASED ON DAY,CUSTOMER AND RETURN LIST OF FLIGHTS
    public List<Flight> removeCustomerB(String name,String date){
        
        List<Flight> flights = null;
        ResultSet resultSet = null;
        
        try{
            
            //search bookings
            String search = "SELECT Flight From Bookings WHERE Customer ='" + name +"'" +
                "AND Day = '" + date +"'"; 
            searchFlightsBookings = connection.prepareStatement(search);
            
            resultSet = searchFlightsBookings.executeQuery();
            flights = new ArrayList<Flight>();
            while (resultSet.next()){
                flights.add(new Flight(
                        resultSet.getString("Flight")));
            }
            
            //Remove the Customers
            String remove = "DELETE FROM Bookings WHERE Customer ='" + name +"'" +
                "AND Day = '" + date +"'"; 
            removeCustomerDay = connection.prepareStatement(remove);
            removeCustomerDay.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
        return flights;
    }
    
    //REMOVE CUSTOMER's WAITLIST BASED ON DAY,CUSTOMER AND RETURN LIST OF FLIGHTS
    public List<Flight> removeCustomerW(String name,String date){
        
        List<Flight> flights = null;
        ResultSet resultSet2 = null;
        
        try{
            //search Waitlist
            String search2 = "SELECT Flight From Waitlist WHERE Customer ='" + name +"'" +
                "AND Day = '" + date +"'"; 
            searchFlightsWaitlist = connection.prepareStatement(search2);
            
            resultSet2 = searchFlightsWaitlist.executeQuery();
            flights = new ArrayList<Flight>();
            while (resultSet2.next()){
                flights.add(new Flight(
                        resultSet2.getString("Flight")));
            }
            
            //Remove the Customers
            String remove2 = "DELETE FROM Waitlist WHERE Customer ='" + name +"'" +
                "AND Day = '" + date +"'";
            removeCustomerDay2 = connection.prepareStatement(remove2);
            removeCustomerDay2.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
        return flights;
    }//
    
    //ADD BOOKING TO DATABASE
    public void addBooking(String customer, String flight, String day){
        String customerString = getWaitlistCustomers();
        
        
        /*if (customerString.contains(customer))
        {
            //remove Customer from waitlist
            try{ 
            String delete = ("DELETE FROM Waitlist WHERE Customer ='"+customer+"'");
            deleteFromWaitlist = connection.prepareStatement(delete);
            deleteFromWaitlist.executeUpdate();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        */
        
        try{
            insertNewBooking.setString(1,customer);
            insertNewBooking.setString(2,flight);
            insertNewBooking.setString(3,day);
            insertNewBooking.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //ADD BOOKING TO DATABASE
    public void updateBooking(String customer, String flight, String day){
        try{
            String string = "UPDATE Bookings SET Flight = '"+flight+"',Day = '"+day+"' WHERE Customer = '"+
                    customer+"'";
            updateBooking = connection.prepareStatement(string);
            updateBooking.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //ADD WAITLIST TO DATABASE
    public void addWaitlist(String customer, String flight, String day){
        try{
            insertNewWaitlist.setString(1,customer);
            insertNewWaitlist.setString(2,flight);
            insertNewWaitlist.setString(3,day);
            insertNewWaitlist.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            close();
        }
    }//
    
    //RETRIEVE LIST OF CUSTOMERS
    public List<Customer> getAllCustomers(){
        List<Customer> results = null;
        ResultSet resultSet = null;
        try{
            resultSet = selectAllCustomers.executeQuery();
            results = new ArrayList<Customer>();
            while (resultSet.next()){
                results.add(new Customer(
                        resultSet.getString("Name")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE LIST OF CUSTOMERS by FLIGHT
    public List<Customer> getFlightCustomers(String flight){
        List<Customer> results = null;
        ResultSet resultSet = null;
        
        String search = "SELECT Customer FROM Bookings WHERE Flight = '"+flight+"'";
        try{
            selectFlightCustomers = connection.prepareStatement(search);
            resultSet = selectFlightCustomers.executeQuery();
            results = new ArrayList<Customer>();
            while (resultSet.next()){
                results.add(new Customer(
                        resultSet.getString("Customer")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE LIST OF Flights
    public List<Flight> getAllFlights(){
        List<Flight> results = null;
        ResultSet resultSet = null;
        try{
            resultSet = selectAllFlights.executeQuery();
            results = new ArrayList<Flight>();
            while (resultSet.next()){
                results.add(new Flight(
                        resultSet.getString("Name")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE LIST OF Days
    public List<Day> getAllDates(){
        List<Day> results = null;
        ResultSet resultSet = null;
        try{
            resultSet = selectAllDates.executeQuery();
            results = new ArrayList<Day>();
            while (resultSet.next()){
                results.add(new Day(
                        resultSet.getString("Date")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE DATE STRING FOR ONE CUSTOMER
    public String getOneDate(String customer){
        List<Day> results = null;
        ResultSet resultSet = null;
        try{
            String search = "SELECT Day FROM Bookings WHERE Customer = '"+customer+"'";
            selectOneDate = connection.prepareStatement(search);
            resultSet = selectOneDate.executeQuery();
            results = new ArrayList<Day>();
            while (resultSet.next()){
                results.add(new Day(
                        resultSet.getString("Day")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results.get(0).toString();
    }//
    
    //CLOSE OPERATION
    public void close(){
        try{
            connection.close();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }//
    
    //RETRIEVE STRING OF BOOKED CUSTOMERS
    public String getBookingCustomers(){
        List<Customer> results = null;
        ResultSet resultSet = null;
        try{
            resultSet = selectBookingCustomers.executeQuery();
            results = new ArrayList<Customer>();
            while (resultSet.next()){
                results.add(new Customer(
                        resultSet.getString("Customer")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results.toString();
    }//
    
    //RETRIEVE STRING OF WAITLISTED CUSTOMERS
    public String getWaitlistCustomers(){
        List<Customer> results = null;
        ResultSet resultSet = null;
        try{
            resultSet = selectWaitlistCustomers.executeQuery();
            results = new ArrayList<Customer>();
            while (resultSet.next()){
                results.add(new Customer(
                        resultSet.getString("Customer")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results.toString();
    }//
   
    //RETRIEVE CUSTOMERS & FLIGHT FROM WAITLIST BASED ON DAY
    public List<String> getStatusWaitlist(String statusDay){
        List<String> results = null;
        ResultSet resultSet = null;
        
        try{
            String statusWaitlist = "SELECT Customer,Flight FROM Waitlist WHERE Day = '" + statusDay + "'ORDER BY Timestamp asc";
            selectCustomersWaitlistStatus = connection.prepareStatement(statusWaitlist);
            
            resultSet = selectCustomersWaitlistStatus.executeQuery();
            results = new ArrayList<String>();
            while (resultSet.next()){
                results.add(new String(resultSet.getString("Customer")+" on Flight " + resultSet.getString("Flight") +"\n"));
                //System.out.println(resultSet.getString("Customer"));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }
    
    
    //RETURNS TRUE IF FLIGHT IS FULL
    public boolean isWaitlisted(String flight, String day){
        //A - check # of seats available for flight in FLIGHT

        ResultSet resultSet;
      
        List<Customer> customerList = getStatusFlightDay(flight,day);
        int customerListSize = customerList.size();
        
        //B - check # of customers for that flight & day in BOOKINGS
        try{
            seatCheck = connection.prepareStatement("SELECT Seats FROM Flight WHERE Name = '" + flight +"'");
            resultSet = seatCheck.executeQuery();
            while (resultSet.next()) {
                int seatsNum = resultSet.getInt("Seats"); //seatsNum = # of seats Available
                
                //If A == B, put customer on waitlist
                if (seatsNum == customerListSize)
                    return true;
                //System.out.printf("seatsNUM %d",seatsNum);
            }
        }
        catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        return false;
    }//
    
    //RETRIEVE LIST OF CUSTOMERS FOR SPECIFIC FLIGHT/DAY
    public List<Customer> getStatusFlightDay(String statusFlight, String statusDay){
        List<Customer> results = null;
        ResultSet resultSet = null;
        try{
            
            String statusFlightDayString = "SELECT Customer FROM Bookings WHERE Flight = '" + statusFlight + "'"+
            "AND Day = '" + statusDay + "'ORDER BY Timestamp asc";
            
            selectCustomersFlightDayStatus = connection.prepareStatement(statusFlightDayString);
            
            resultSet = selectCustomersFlightDayStatus.executeQuery();
            results = new ArrayList<Customer>();
            while (resultSet.next()){
                results.add(new Customer(
                        resultSet.getString("Customer")));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE FLIGHT,DAY FROM BOOKINGS BASED ON CUSTOMER
    public List<String> getCustomerStatusBooking(String customer){
        List<String> results = null;
        ResultSet resultSet = null;
        
        try{
            String statusCustomer = "SELECT Flight,Day FROM Bookings WHERE Customer = '" + customer+"'";
            selectCustomersStatusBookings = connection.prepareStatement(statusCustomer);
            
            resultSet = selectCustomersStatusBookings.executeQuery();
            results = new ArrayList<String>();
            while (resultSet.next()){
                results.add(new String("Customer " + customer +" is booked on Flight " + resultSet.getString("Flight") + " on day " + resultSet.getString("Day") +"\n"));
                //System.out.println(resultSet.getString("Customer"));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVE FLIGHT,DAY FROM WAITLIST BASED ON CUSTOMER
    public List<String> getCustomerStatusWaitlist(String customer){
        List<String> results = null;
        ResultSet resultSet = null;
        
        try{
            String statusCustomer = "SELECT Flight,Day FROM Waitlist WHERE Customer = '" + customer+"'";
            selectCustomersStatusWaitlist = connection.prepareStatement(statusCustomer);
            
            resultSet = selectCustomersStatusWaitlist.executeQuery();
            results = new ArrayList<String>();
            while (resultSet.next()){
                results.add(new String("Customer " + customer +" is waitlisted for Flight " + resultSet.getString("Flight") + " on day " + resultSet.getString("Day") +"\n"));
                //System.out.println(resultSet.getString("Customer"));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        return results;
    }//
    
    //RETRIEVES CUSTOMER FROM WAITLIST BASED ON FLIGHT/DAY AND BOOKS THEM
    public String bump(String flight, String date){
        String search = "SELECT Customer FROM Waitlist WHERE Flight = '"+flight+"' AND Day = '" + date+"'ORDER BY Timestamp asc";
        List<String> results = null;
        ResultSet resultSet = null;
        
        String customer;
        
        try{
            bump = connection.prepareStatement(search);
            
            resultSet = bump.executeQuery();
            results = new ArrayList<String>();
            while (resultSet.next()){
                results.add(new String(resultSet.getString("Customer")));
            }
            
            
            // if this guy has bookings, update them with new info
            customer = results.get(0);
            if (customer != null)
            {
            search = "DELETE FROM Bookings WHERE Customer = '"+customer+"'";
            bump = connection.prepareStatement(search);
            bump.executeUpdate();
            addBooking(customer,flight,date);
            
            //delete customer (bumped) from waitlist
            search = "DELETE FROM Waitlist WHERE Customer= '"+customer+
                    "' AND Flight='"+flight+"' AND Day='"+date+"'";
            bump = connection.prepareStatement(search);
            bump.executeUpdate();
            }
            
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        finally{
            try{
                resultSet.close();
            }
            catch(SQLException sqlException){
                sqlException.printStackTrace();
                close();
            }
        }
        
        customer = results.get(0);
        return customer;
    }//
    
}//END CLASS BookingQueries

